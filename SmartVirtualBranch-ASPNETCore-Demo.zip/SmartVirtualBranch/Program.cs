using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Hubs;
using SmartVirtualBranch.Models;
using SmartVirtualBranch.Services;

var builder = WebApplication.CreateBuilder(args);

// In-memory EF Core store so the demo runs with zero external database setup.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("SmartVirtualBranchDb"));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        options.SignIn.RequireConfirmedAccount = false;
        options.Password.RequireNonAlphanumeric = false;
        options.Password.RequireUppercase = false;
        options.Password.RequiredLength = 6;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Identity/Account/Login";
    options.LogoutPath = "/Identity/Account/Logout";
    options.AccessDeniedPath = "/Identity/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromHours(8);
});

builder.Services.AddScoped<IComplaintAgentPipelineService, ComplaintAgentPipelineService>();
builder.Services.AddScoped<IPlatformSettingsService, PlatformSettingsService>();
builder.Services.AddScoped<IGeminiAgentClient, GeminiAgentClient>();
builder.Services.AddScoped<IClaudeAgentClient, ClaudeAgentClient>();
builder.Services.AddScoped<ILlmProviderRouter, LlmProviderRouter>();
builder.Services.AddScoped<IElevenLabsSpeechClient, ElevenLabsSpeechClient>();
builder.Services.AddScoped<ITalkingAgentService, TalkingAgentService>();
builder.Services.AddScoped<ICaseRealtimeNotifier, CaseRealtimeNotifier>();

// Real-time transport for live case updates (Talking Agent style "watch the agents work" reveal,
// Expert Chat, and the Follow-Up Agent's nudges/escalations below).
builder.Services.AddSignalR();

// The "AI keeps working after the pipeline finishes" half of the same-day resolution promise -
// see CaseFollowUpBackgroundService for the idle-nudge / auto-escalation logic.
builder.Services.AddHostedService<CaseFollowUpBackgroundService>();

builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "X-CSRF-TOKEN";
});

builder.Services.AddHttpClient("gemini", client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
});

builder.Services.AddHttpClient("claude", client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
});

builder.Services.AddHttpClient("elevenlabs", client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
});

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();
app.MapHub<CaseHub>("/hubs/case");

using (var scope = app.Services.CreateScope())
{
    await SeedData.InitializeAsync(scope.ServiceProvider);
}

app.Run();
