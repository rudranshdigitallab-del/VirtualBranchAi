using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;
using SmartVirtualBranch.Services;

namespace SmartVirtualBranch.Controllers;

[Authorize(Roles = "Administrator")]
public class AdminController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IPlatformSettingsService _settingsService;

    public AdminController(ApplicationDbContext context, UserManager<ApplicationUser> userManager, IPlatformSettingsService settingsService)
    {
        _context = context;
        _userManager = userManager;
        _settingsService = settingsService;
    }

    public async Task<IActionResult> Index()
    {
        var users = await _userManager.Users.OrderBy(u => u.Email).ToListAsync();
        var userRoles = new Dictionary<string, IList<string>>();
        foreach (var u in users)
        {
            userRoles[u.Id] = await _userManager.GetRolesAsync(u);
        }

        ViewBag.Users = users;
        ViewBag.UserRoles = userRoles;
        ViewBag.Complaints = await _context.Complaints.OrderByDescending(c => c.CreatedAt).ToListAsync();
        ViewBag.Settings = await _settingsService.GetAsync();

        // Token utilization - by agent and grand total. Only ever populated by real Gemini calls.
        var usageRows = await _context.AgentTokenUsages.ToListAsync();
        ViewBag.TotalCalls = usageRows.Count;
        ViewBag.SuccessfulCalls = usageRows.Count(u => u.Success);
        ViewBag.FailedCalls = usageRows.Count(u => !u.Success);
        ViewBag.TotalPromptTokens = usageRows.Sum(u => u.PromptTokens);
        ViewBag.TotalCompletionTokens = usageRows.Sum(u => u.CompletionTokens);
        ViewBag.TotalTokens = usageRows.Sum(u => u.TotalTokens);

        ViewBag.UsageByAgent = usageRows
            .GroupBy(u => u.AgentName)
            .Select(g => new AgentUsageSummary(
                g.Key,
                g.Count(),
                g.Sum(u => u.PromptTokens),
                g.Sum(u => u.CompletionTokens),
                g.Sum(u => u.TotalTokens)))
            .OrderByDescending(x => x.TotalTokens)
            .ToList();

        // Closed Complaints Knowledge Base - how much staff have uploaded, and how often the
        // Pattern Resolution Agent has actually drawn on it.
        var kbEntries = await _context.KnowledgeBaseCases.ToListAsync();
        ViewBag.KbTotalEntries = kbEntries.Count;
        ViewBag.KbTotalMatches = kbEntries.Sum(k => k.TimesMatched);

        // Customer feedback on AI-suggested replies.
        var ratings = await _context.ComplaintReplyRatings.Include(r => r.Complaint).ToListAsync();
        ViewBag.RatingCount = ratings.Count;
        ViewBag.RatingAverage = ratings.Count > 0 ? Math.Round(ratings.Average(r => r.Stars), 2) : (double?)null;
        ViewBag.LowRatings = ratings.Where(r => r.Stars <= 2).OrderByDescending(r => r.RatedAt).Take(5).ToList();

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> AiSettings()
    {
        var settings = await _settingsService.GetAsync();
        return View(settings);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AiSettings(
        bool liveModeEnabled,
        string llmProvider,
        string? geminiApiKey,
        string geminiModel,
        string? claudeApiKey,
        string claudeModel,
        decimal costPerMillionTokensUsd,
        string speechProvider,
        string? elevenLabsApiKey,
        string elevenLabsVoiceId)
    {
        var update = new PlatformSettingsUpdate(
            liveModeEnabled, llmProvider, geminiApiKey, geminiModel, claudeApiKey, claudeModel,
            costPerMillionTokensUsd, speechProvider, elevenLabsApiKey, elevenLabsVoiceId);

        await _settingsService.UpdateAsync(update, User.Identity?.Name ?? "Administrator");
        TempData["Flash"] = "AI settings saved.";
        return RedirectToAction(nameof(AiSettings));
    }
}
