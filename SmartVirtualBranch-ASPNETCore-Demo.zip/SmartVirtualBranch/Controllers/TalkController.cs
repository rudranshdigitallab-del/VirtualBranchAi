using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SmartVirtualBranch.Models;
using SmartVirtualBranch.Services;

namespace SmartVirtualBranch.Controllers;

public class TalkTurnRequest
{
    public string? State { get; set; }
    public string? Message { get; set; }
    public string? PendingMessage { get; set; }
    public string? ChannelSource { get; set; }
}

public class SpeakRequest
{
    public string? Text { get; set; }
}

[Authorize]
public class TalkController : Controller
{
    private readonly ITalkingAgentService _talkingAgent;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IPlatformSettingsService _settingsService;
    private readonly IElevenLabsSpeechClient _speechClient;

    public TalkController(
        ITalkingAgentService talkingAgent,
        UserManager<ApplicationUser> userManager,
        IPlatformSettingsService settingsService,
        IElevenLabsSpeechClient speechClient)
    {
        _talkingAgent = talkingAgent;
        _userManager = userManager;
        _settingsService = settingsService;
        _speechClient = speechClient;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Send([FromBody] TalkTurnRequest request)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return Unauthorized();
        }

        var result = await _talkingAgent.HandleTurnAsync(
            user,
            string.IsNullOrWhiteSpace(request.State) ? "awaiting_complaint" : request.State!,
            request.Message ?? string.Empty,
            request.PendingMessage,
            string.IsNullOrWhiteSpace(request.ChannelSource) ? "Live Chat" : request.ChannelSource!);

        return Json(result);
    }

    /// <summary>
    /// Server-side text-to-speech via a real third-party speech engine (ElevenLabs) - the API key
    /// never reaches the browser. Returns 204 (no content) whenever ElevenLabs isn't configured or
    /// the call fails, so the client can fall back to the browser's built-in Web Speech API without
    /// ever breaking the conversation. Anthropic has no public speech API to call here - see the
    /// note on ClaudeAgentClient.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Speak([FromBody] SpeakRequest request)
    {
        var text = (request.Text ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(text))
        {
            return NoContent();
        }

        var settings = await _settingsService.GetAsync();
        if (settings.SpeechProvider != "ElevenLabs" || string.IsNullOrWhiteSpace(settings.ElevenLabsApiKey))
        {
            return NoContent();
        }

        var result = await _speechClient.SynthesizeAsync(text, settings.ElevenLabsVoiceId, settings.ElevenLabsApiKey);
        if (!result.Success || result.AudioBytes == null)
        {
            return NoContent();
        }

        return File(result.AudioBytes, "audio/mpeg");
    }
}
