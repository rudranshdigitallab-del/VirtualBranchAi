using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SmartVirtualBranch.Controllers;

// "Knowledge & Policies" style transparency page: shows every agent's role,
// which phase it runs in, and the exact instruction/system prompt it would
// be given if wired to a real LLM.
[Authorize]
public class AgentsController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}
