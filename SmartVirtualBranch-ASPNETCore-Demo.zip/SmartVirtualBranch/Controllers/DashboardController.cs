using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;

namespace SmartVirtualBranch.Controllers;

[Authorize]
public class DashboardController : Controller
{
    private readonly ApplicationDbContext _context;

    public DashboardController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var isStaff = User.IsInRole("BranchOfficer") || User.IsInRole("BranchManager")
                      || User.IsInRole("OperationsTeam") || User.IsInRole("Administrator");

        var query = _context.Complaints.AsQueryable();

        if (!isStaff)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            query = query.Where(c => c.CustomerUserId == userId);
        }

        ViewBag.TotalComplaints = await query.CountAsync();
        ViewBag.OpenComplaints = await query.CountAsync(c => c.Status != "Closed");
        ViewBag.EscalatedComplaints = await query.CountAsync(c => c.Status == "Escalated");
        ViewBag.AutoResolvedComplaints = await query.CountAsync(c => c.Status == "Auto-Resolved");
        ViewBag.ClosedComplaints = await query.CountAsync(c => c.Status == "Closed");

        return View();
    }
}
