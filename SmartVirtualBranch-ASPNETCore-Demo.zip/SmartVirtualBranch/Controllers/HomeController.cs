using Microsoft.AspNetCore.Mvc;

namespace SmartVirtualBranch.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        if (User.Identity is { IsAuthenticated: true })
        {
            return RedirectToAction("Index", "Dashboard");
        }

        return RedirectToPage("/Account/Login", new { area = "Identity" });
    }

    public IActionResult Error()
    {
        return View();
    }
}
