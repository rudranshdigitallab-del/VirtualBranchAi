using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;
using SmartVirtualBranch.Services;

namespace SmartVirtualBranch.Controllers;

public class ExpertChatSendRequest
{
    public int ComplaintId { get; set; }
    public string Message { get; set; } = string.Empty;
}

[Authorize]
public class ComplaintsController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IComplaintAgentPipelineService _pipeline;
    private readonly ICaseRealtimeNotifier _notifier;
    private readonly IServiceScopeFactory _scopeFactory;

    public ComplaintsController(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        IComplaintAgentPipelineService pipeline,
        ICaseRealtimeNotifier notifier,
        IServiceScopeFactory scopeFactory)
    {
        _context = context;
        _userManager = userManager;
        _pipeline = pipeline;
        _notifier = notifier;
        _scopeFactory = scopeFactory;
    }

    private bool IsStaff => User.IsInRole("BranchOfficer") || User.IsInRole("BranchManager")
                             || User.IsInRole("OperationsTeam") || User.IsInRole("Administrator");

    public async Task<IActionResult> Index()
    {
        var user = await _userManager.GetUserAsync(User);
        var query = _context.Complaints.AsQueryable();

        if (!IsStaff)
        {
            query = query.Where(c => c.CustomerUserId == user!.Id);
        }

        var complaints = await query.OrderByDescending(c => c.CreatedAt).ToListAsync();
        return View(complaints);
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View(new Complaint { ChannelSource = "Website / Portal" });
    }

    /// <summary>
    /// Saves the case immediately in an "Analyzing" state and redirects to its Details page right
    /// away - the AI Agent Orchestration Layer then runs in the background and the customer watches
    /// each agent's step stream in live over SignalR (see RunPipelineInBackgroundAsync below), rather
    /// than the browser blocking on the whole pipeline inside this one HTTP request.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("ChannelSource,Description")] Complaint model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var user = await _userManager.GetUserAsync(User);

        var complaint = new Complaint
        {
            CustomerUserId = user!.Id,
            CustomerName = string.IsNullOrWhiteSpace(user.FullName) ? user.Email! : user.FullName,
            ChannelSource = model.ChannelSource,
            Description = model.Description,
            Category = "Auto-detect",
            Status = "Analyzing",
            CreatedAt = DateTime.UtcNow
        };

        _context.Complaints.Add(complaint);
        await _context.SaveChangesAsync();

        var complaintId = complaint.Id;

        // Demo-appropriate fire-and-forget: a production deployment should hand this to a durable
        // background queue (Hangfire, Azure Queue + Function, etc.) instead of a bare Task.Run.
        _ = Task.Run(() => RunPipelineInBackgroundAsync(complaintId));

        TempData["Flash"] = $"Case received - reference will appear shortly. The AI Agent Orchestration Layer is analyzing it live below.";
        return RedirectToAction(nameof(Details), new { id = complaintId });
    }

    private async Task RunPipelineInBackgroundAsync(int complaintId)
    {
        using var scope = _scopeFactory.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var pipeline = scope.ServiceProvider.GetRequiredService<IComplaintAgentPipelineService>();
        var notifier = scope.ServiceProvider.GetRequiredService<ICaseRealtimeNotifier>();

        var complaint = await context.Complaints.FindAsync(complaintId);
        if (complaint == null)
        {
            return;
        }

        await notifier.ProcessingStartedAsync(complaintId);

        var events = await pipeline.RunPipelineAsync(complaint, notifier);
        foreach (var ev in events)
        {
            ev.ComplaintId = complaint.Id;
            context.ComplaintTimelineEvents.Add(ev);
        }
        await context.SaveChangesAsync();

        await pipeline.PostInitialExpertChatSummaryAsync(complaint, notifier);

        await notifier.ProcessingCompletedAsync(complaintId, $"/Complaints/Details/{complaintId}");
    }

    public async Task<IActionResult> Details(int id)
    {
        var complaint = await _context.Complaints
            .Include(c => c.TimelineEvents.OrderBy(e => e.StepOrder))
            .FirstOrDefaultAsync(c => c.Id == id);

        if (complaint == null)
        {
            return NotFound();
        }

        var user = await _userManager.GetUserAsync(User);
        if (!IsStaff && complaint.CustomerUserId != user!.Id)
        {
            return Forbid();
        }

        ViewBag.TokenUsage = await _context.AgentTokenUsages
            .Where(u => u.ComplaintId == id)
            .OrderBy(u => u.Timestamp)
            .ToListAsync();

        ViewBag.MyRating = await _context.ComplaintReplyRatings.FirstOrDefaultAsync(r => r.ComplaintId == id);

        ViewBag.ExpertChat = await _context.ExpertChatMessages
            .Where(m => m.ComplaintId == id)
            .OrderBy(m => m.Timestamp)
            .ToListAsync();

        return View(complaint);
    }

    /// <summary>
    /// The customer rates the AI-suggested resolution on their own case (1-5 stars, optional
    /// comment). Only the case owner can rate, and only once per case - re-submitting overwrites
    /// the previous rating rather than adding a duplicate.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> RateReply(int id, int stars, string? comment)
    {
        if (stars < 1 || stars > 5)
        {
            TempData["FlashError"] = "Please choose a rating between 1 and 5 stars.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var complaint = await _context.Complaints.FirstOrDefaultAsync(c => c.Id == id);
        if (complaint == null)
        {
            return NotFound();
        }

        var user = await _userManager.GetUserAsync(User);
        if (complaint.CustomerUserId != user!.Id)
        {
            return Forbid();
        }

        var existing = await _context.ComplaintReplyRatings.FirstOrDefaultAsync(r => r.ComplaintId == id);
        if (existing != null)
        {
            existing.Stars = stars;
            existing.Comment = comment;
            existing.RatedAt = DateTime.UtcNow;
        }
        else
        {
            _context.ComplaintReplyRatings.Add(new ComplaintReplyRating
            {
                ComplaintId = id,
                RatedByUserId = user.Id,
                Stars = stars,
                Comment = comment
            });
        }

        await _context.SaveChangesAsync();
        TempData["Flash"] = "Thanks - your rating helps train the AI Branch Officer's future replies.";
        return RedirectToAction(nameof(Details), new { id });
    }

    /// <summary>
    /// AJAX endpoint for the Expert Chat: the officer's message is saved and pushed live first, then
    /// the AI Case Agent answers deterministically from the case's own grounding facts (policy
    /// citation, matched precedent, confidence, same-day target) - never invents anything new. Both
    /// messages arrive over SignalR to everyone viewing the case, including the sender.
    /// </summary>
    [HttpPost]
    [Authorize(Roles = "BranchOfficer,BranchManager,OperationsTeam,Administrator")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ExpertChatSend([FromBody] ExpertChatSendRequest request)
    {
        var message = (request.Message ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(message))
        {
            return BadRequest();
        }

        var complaint = await _context.Complaints
            .Include(c => c.TimelineEvents)
            .FirstOrDefaultAsync(c => c.Id == request.ComplaintId);
        if (complaint == null)
        {
            return NotFound();
        }

        var officerMessage = new ExpertChatMessage
        {
            ComplaintId = complaint.Id,
            SenderType = "Officer",
            SenderName = User.Identity?.Name ?? "Officer",
            Message = message,
            Timestamp = DateTime.UtcNow
        };
        _context.ExpertChatMessages.Add(officerMessage);
        await _context.SaveChangesAsync();
        await _notifier.ExpertChatMessageAddedAsync(complaint.Id, officerMessage);

        var aiMessage = new ExpertChatMessage
        {
            ComplaintId = complaint.Id,
            SenderType = "AI",
            SenderName = "AI Case Agent",
            Message = BuildExpertChatAiReply(complaint, message),
            Timestamp = DateTime.UtcNow
        };
        _context.ExpertChatMessages.Add(aiMessage);
        await _context.SaveChangesAsync();
        await _notifier.ExpertChatMessageAddedAsync(complaint.Id, aiMessage);

        return Json(new { ok = true });
    }

    private static string BuildExpertChatAiReply(Complaint complaint, string officerMessage)
    {
        var lower = officerMessage.ToLowerInvariant();
        var events = complaint.TimelineEvents;

        if (lower.Contains("polic"))
        {
            var policyEvent = events.FirstOrDefault(e => e.AgentName == "Policy Intelligence Agent");
            return policyEvent != null
                ? $"Policy Intelligence Agent's note: {policyEvent.Output}"
                : "No policy citation has been retrieved for this case yet.";
        }

        if (lower.Contains("precedent") || lower.Contains("pattern") || lower.Contains("match"))
        {
            var patternEvent = events.FirstOrDefault(e => e.AgentName == "Pattern Resolution Agent");
            return patternEvent != null
                ? $"Pattern Resolution Agent's note: {patternEvent.Output}"
                : "No pattern match check has run for this case yet.";
        }

        if (lower.Contains("confiden"))
        {
            return $"AI confidence on this case is {(complaint.AiConfidenceScore * 100):0}%.";
        }

        if (lower.Contains("sla") || lower.Contains("deadline") || lower.Contains("time") || lower.Contains("target"))
        {
            var remaining = complaint.SameDayTargetAt - DateTime.UtcNow;
            return remaining.TotalMinutes > 0
                ? $"Same-day target is {complaint.SameDayTargetAt:HH:mm} today - about {(int)remaining.TotalHours}h {remaining.Minutes}m remaining. Priority SLA is due {complaint.SlaDueAt:dd-MMM HH:mm} UTC."
                : "This case is past its same-day target - recommend prioritizing it right now.";
        }

        if (lower.Contains("recap") || lower.Contains("summary") || lower.Contains("recommend"))
        {
            return $"Recap: {complaint.Category}, {complaint.Priority} priority, status {complaint.Status}. " +
                   (string.IsNullOrWhiteSpace(complaint.RootCauseSummary)
                       ? "No resolution drafted yet - see the Investigation and Policy Intelligence findings on the case timeline."
                       : $"Recommended resolution: {complaint.RootCauseSummary}");
        }

        if (lower.Contains("escalat"))
        {
            return "I can't escalate on my own - use the Escalate button on the case page and I'll log it to the timeline right away.";
        }

        return "Noted. Ask me for the policy citation, matched precedent, AI confidence, same-day target, or a full case recap anytime.";
    }

    [HttpPost]
    [Authorize(Roles = "BranchOfficer,BranchManager,Administrator")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Resolve(int id)
    {
        var complaint = await _context.Complaints.Include(c => c.TimelineEvents).FirstOrDefaultAsync(c => c.Id == id);
        if (complaint == null)
        {
            return NotFound();
        }

        complaint.Status = "Closed";
        complaint.RootCauseSummary ??= "Resolved by a human agent following the AI-recommended resolution path.";
        complaint.AssignedOfficer = User.Identity?.Name ?? complaint.AssignedOfficer;

        var closeEvent = new ComplaintTimelineEvent
        {
            ComplaintId = complaint.Id,
            StepOrder = complaint.TimelineEvents.Count + 1,
            Phase = 8,
            AgentName = "Closure Agent",
            Action = "Case closed",
            Output = $"Closed by {User.Identity!.Name} with human approval; audit trail recorded.",
            Timestamp = DateTime.UtcNow
        };
        _context.ComplaintTimelineEvents.Add(closeEvent);

        await _context.SaveChangesAsync();
        await _notifier.TimelineEventAddedAsync(id, closeEvent);
        await _notifier.StatusChangedAsync(id, complaint.Status, complaint.Priority, complaint.AssignedOfficer);

        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    [Authorize(Roles = "BranchOfficer,BranchManager,Administrator")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Escalate(int id)
    {
        var complaint = await _context.Complaints.Include(c => c.TimelineEvents).FirstOrDefaultAsync(c => c.Id == id);
        if (complaint == null)
        {
            return NotFound();
        }

        complaint.Status = "Escalated";
        complaint.AssignedOfficer = "Branch Manager Queue";

        var escalateEvent = new ComplaintTimelineEvent
        {
            ComplaintId = complaint.Id,
            StepOrder = complaint.TimelineEvents.Count + 1,
            Phase = 7,
            AgentName = "Escalation Agent",
            Action = "Manually escalated",
            Output = $"Escalated by {User.Identity!.Name} to the Branch Manager queue.",
            Timestamp = DateTime.UtcNow
        };
        _context.ComplaintTimelineEvents.Add(escalateEvent);

        await _context.SaveChangesAsync();
        await _notifier.TimelineEventAddedAsync(id, escalateEvent);
        await _notifier.StatusChangedAsync(id, complaint.Status, complaint.Priority, complaint.AssignedOfficer);

        return RedirectToAction(nameof(Details), new { id });
    }
}
