using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Controllers;

/// <summary>
/// Lets staff upload historical CLOSED complaints - one at a time, or in bulk via a CSV - so the
/// Pattern Resolution Agent has a wider precedent library to draw drafted resolutions from. See
/// <see cref="KnowledgeBaseCase"/> and <c>ComplaintAgentPipelineService.FindPatternResolution</c>.
/// </summary>
[Authorize(Roles = "BranchOfficer,BranchManager,OperationsTeam,Administrator")]
public class KnowledgeBaseController : Controller
{
    private static readonly string[] Categories = { "Loan", "Card", "Payment", "Account", "Fraud", "General Banking" };

    private readonly ApplicationDbContext _context;

    public KnowledgeBaseController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var entries = await _context.KnowledgeBaseCases.OrderByDescending(k => k.UploadedAt).ToListAsync();
        ViewBag.TotalEntries = entries.Count;
        ViewBag.TotalMatches = entries.Sum(e => e.TimesMatched);
        ViewBag.CategoryCount = entries.Select(e => e.Category).Distinct().Count();
        return View(entries);
    }

    [HttpGet]
    public IActionResult Upload()
    {
        ViewBag.Categories = Categories;
        return View(new KnowledgeBaseCase());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload([Bind("Category,IssueDescription,ResolutionApplied")] KnowledgeBaseCase model)
    {
        ViewBag.Categories = Categories;

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        model.UploadedBy = User.Identity?.Name ?? "Unknown";
        model.UploadedAt = DateTime.UtcNow;
        model.Source = "Manual Entry";

        _context.KnowledgeBaseCases.Add(model);
        await _context.SaveChangesAsync();

        TempData["Flash"] = $"Added precedent {model.ReferenceCode} to the Closed Complaints Knowledge Base. " +
            "The Pattern Resolution Agent will consider it for every future case in the same category.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>
    /// Minimal, dependency-free CSV parser for the demo: expects a header row followed by rows of
    /// Category,IssueDescription,ResolutionApplied - double-quoted fields (for commas inside text)
    /// are supported, escaped quotes ("") are not. Malformed rows are skipped and reported back,
    /// never silently dropped without a count.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> BulkUpload(IFormFile? csvFile)
    {
        if (csvFile == null || csvFile.Length == 0)
        {
            TempData["FlashError"] = "Please choose a CSV file to upload.";
            return RedirectToAction(nameof(Upload));
        }

        if (!csvFile.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
        {
            TempData["FlashError"] = "Only .csv files are supported in this demo.";
            return RedirectToAction(nameof(Upload));
        }

        using var reader = new StreamReader(csvFile.OpenReadStream());
        var lines = new List<string>();
        while (!reader.EndOfStream)
        {
            var line = await reader.ReadLineAsync();
            if (!string.IsNullOrWhiteSpace(line))
            {
                lines.Add(line);
            }
        }

        if (lines.Count <= 1)
        {
            TempData["FlashError"] = "The file had no data rows. Expected a header, then Category,IssueDescription,ResolutionApplied per line.";
            return RedirectToAction(nameof(Upload));
        }

        var uploadedBy = User.Identity?.Name ?? "Unknown";
        var added = 0;
        var skipped = 0;

        // Skip the header row (line 0).
        for (int i = 1; i < lines.Count; i++)
        {
            var fields = ParseCsvLine(lines[i]);
            if (fields.Count < 3)
            {
                skipped++;
                continue;
            }

            var category = fields[0].Trim();
            var issue = fields[1].Trim();
            var resolution = fields[2].Trim();

            if (string.IsNullOrWhiteSpace(issue) || string.IsNullOrWhiteSpace(resolution) || issue.Length < 10)
            {
                skipped++;
                continue;
            }

            if (!Categories.Contains(category, StringComparer.OrdinalIgnoreCase))
            {
                category = "General Banking";
            }

            _context.KnowledgeBaseCases.Add(new KnowledgeBaseCase
            {
                Category = category,
                IssueDescription = issue,
                ResolutionApplied = resolution,
                UploadedBy = uploadedBy,
                UploadedAt = DateTime.UtcNow,
                Source = "CSV Bulk Upload"
            });
            added++;
        }

        await _context.SaveChangesAsync();

        TempData["Flash"] = skipped == 0
            ? $"Imported {added} closed complaint(s) into the Knowledge Base."
            : $"Imported {added} closed complaint(s); skipped {skipped} row(s) that were missing a category, issue, or resolution.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var entry = await _context.KnowledgeBaseCases.FindAsync(id);
        if (entry == null)
        {
            return NotFound();
        }

        _context.KnowledgeBaseCases.Remove(entry);
        await _context.SaveChangesAsync();
        TempData["Flash"] = $"Removed {entry.ReferenceCode} from the Knowledge Base.";
        return RedirectToAction(nameof(Index));
    }

    private static List<string> ParseCsvLine(string line)
    {
        var fields = new List<string>();
        var current = new System.Text.StringBuilder();
        var inQuotes = false;

        for (int i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"')
            {
                inQuotes = !inQuotes;
            }
            else if (c == ',' && !inQuotes)
            {
                fields.Add(current.ToString());
                current.Clear();
            }
            else
            {
                current.Append(c);
            }
        }
        fields.Add(current.ToString());
        return fields;
    }
}
