using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Hubs;

/// <summary>
/// The real-time backbone for a single case. Anyone viewing a case's Details page joins the
/// "case-{id}" group and receives, without refreshing: new AI Agent Orchestration Timeline steps as
/// they're produced, Expert Chat messages between the AI Case Agent and the assigned officer, and
/// status/priority changes (auto-resolution, escalation, closure). See
/// <see cref="Services.ICaseRealtimeNotifier"/> for the server-side broadcast side.
/// </summary>
[Authorize]
public class CaseHub : Hub
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public CaseHub(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    public static string GroupName(int complaintId) => $"case-{complaintId}";

    /// Only the case's own customer, or any staff role, may join its live group - mirrors the
    /// authorization check already enforced by ComplaintsController.Details.
    public async Task JoinCase(int complaintId)
    {
        var complaint = await _context.Complaints.FindAsync(complaintId);
        if (complaint == null)
        {
            return;
        }

        var user = await _userManager.GetUserAsync(Context.User!);
        if (user == null)
        {
            return;
        }

        var isStaff = Context.User!.IsInRole("BranchOfficer") || Context.User.IsInRole("BranchManager")
                      || Context.User.IsInRole("OperationsTeam") || Context.User.IsInRole("Administrator");

        if (isStaff || complaint.CustomerUserId == user.Id)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, GroupName(complaintId));
        }
    }

    public async Task LeaveCase(int complaintId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, GroupName(complaintId));
    }
}
