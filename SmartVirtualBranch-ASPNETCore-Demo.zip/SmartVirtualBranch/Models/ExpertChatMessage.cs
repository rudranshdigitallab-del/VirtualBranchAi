namespace SmartVirtualBranch.Models;

/// <summary>
/// One message in the real-time "Expert Chat" thread on a case - a live back-and-forth between the
/// AI Case Agent and the human officer/manager it's assigned to, distinct from the customer-facing
/// timeline. The AI opens with a summary + recommendation as soon as the orchestration pipeline
/// finishes, answers the officer's follow-up questions from the case's own grounding facts (policy
/// citation, matched precedent, confidence), and the Follow-Up Agent posts nudges here if the case
/// goes quiet - all pushed live over SignalR (<see cref="Hubs.CaseHub"/>) to anyone viewing the case.
/// </summary>
public class ExpertChatMessage
{
    public int Id { get; set; }

    public int ComplaintId { get; set; }
    public Complaint? Complaint { get; set; }

    /// "AI" | "Officer" | "System"
    public string SenderType { get; set; } = "AI";

    public string SenderName { get; set; } = "AI Case Agent";

    public string Message { get; set; } = string.Empty;

    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
