namespace SmartVirtualBranch.Models;

/// <summary>
/// Singleton row (Id = 1) holding the Administrator-controlled AI configuration.
/// DEMO NOTE: API keys are stored in plaintext in the in-memory database purely so this
/// runs with zero extra setup. A production build should keep these in a secrets manager
/// (Azure Key Vault, AWS Secrets Manager, dotnet user-secrets, etc.), never in a normal table.
/// </summary>
public class PlatformSettings
{
    public int Id { get; set; } = 1;

    public bool LiveModeEnabled { get; set; } = false;

    // --- LLM reasoning provider (text only - see ILlmProviderRouter) ---

    /// "Gemini" or "Claude" - which text model the AI Agent Orchestration Layer calls when
    /// LiveModeEnabled is on. Anthropic has no public speech API, so this only ever affects the
    /// text agents; voice I/O is configured separately below.
    public string LlmProvider { get; set; } = "Gemini";

    public string GeminiApiKey { get; set; } = string.Empty;
    public string GeminiModel { get; set; } = "gemini-2.0-flash";

    public string ClaudeApiKey { get; set; } = string.Empty;
    public string ClaudeModel { get; set; } = "claude-sonnet-5";

    /// <summary>
    /// Admin-supplied rate used only to show an ESTIMATED cost next to token totals.
    /// Left at 0 by default so the app never guesses at pricing on its own -
    /// set this from the active provider's current published pricing if you want the estimate.
    /// </summary>
    public decimal CostPerMillionTokensUsd { get; set; } = 0m;

    // --- Speech engine (Talk / AI Branch Officer voice UI) ---

    /// "Browser" (free, uses the Web Speech API already built into the visitor's browser) or
    /// "ElevenLabs" (a real third-party speech engine - natural voice, requires an API key).
    /// Speech-to-text (listening) always uses the browser's Web Speech API in this demo; only
    /// text-to-speech (the AI Branch Officer's spoken replies) switches providers.
    public string SpeechProvider { get; set; } = "Browser";

    public string ElevenLabsApiKey { get; set; } = string.Empty;

    /// Defaults to ElevenLabs' public "Rachel" voice ID as a reasonable out-of-the-box choice.
    public string ElevenLabsVoiceId { get; set; } = "21m00Tcm4TlvDq8ikWAM";

    public DateTime? UpdatedAt { get; set; }

    public string? UpdatedBy { get; set; }
}
