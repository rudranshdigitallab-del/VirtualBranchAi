using System.ComponentModel.DataAnnotations;

namespace SmartVirtualBranch.Models;

public class Complaint
{
    public int Id { get; set; }

    public string ComplaintReference { get; set; } = "SVB-" + Guid.NewGuid().ToString("N")[..8].ToUpper();

    public string CustomerUserId { get; set; } = string.Empty;

    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose the channel this complaint came in on.")]
    [Display(Name = "Channel")]
    public string ChannelSource { get; set; } = "Website / Portal";

    [Required(ErrorMessage = "Please describe the issue in one or two sentences.")]
    [StringLength(1000, MinimumLength = 10, ErrorMessage = "Please provide a bit more detail (10-1000 characters).")]
    [Display(Name = "Describe your issue")]
    public string Description { get; set; } = string.Empty;

    public string Category { get; set; } = "Auto-detect";

    public string Status { get; set; } = "New";

    public string Priority { get; set; } = "Medium";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime SlaDueAt { get; set; }

    /// The "resolve it today" target this whole real-time module is built around - end of the
    /// calendar day the case was filed. Distinct from SlaDueAt (which is priority-based hours);
    /// this is the same-day promise shown to the customer and used by the Follow-Up Agent to decide
    /// when to auto-escalate.
    public DateTime SameDayTargetAt { get; set; }

    /// Last time the Follow-Up Agent nudged anyone about this case - lets the background monitor
    /// throttle itself instead of posting a new nudge every tick.
    public DateTime? LastFollowUpAt { get; set; }

    public string AssignedOfficer { get; set; } = "Unassigned";

    public double AiConfidenceScore { get; set; }

    public string? RootCauseSummary { get; set; }

    public List<ComplaintTimelineEvent> TimelineEvents { get; set; } = new();
}
