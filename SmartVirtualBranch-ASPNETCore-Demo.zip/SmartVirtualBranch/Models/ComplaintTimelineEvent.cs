namespace SmartVirtualBranch.Models;

public class ComplaintTimelineEvent
{
    public int Id { get; set; }
    public int ComplaintId { get; set; }
    public Complaint? Complaint { get; set; }
    public int StepOrder { get; set; }

    // Agents that share a Phase have no dependency on each other and are
    // dispatched by the orchestrator at the same time - i.e. they run side by side.
    public int Phase { get; set; } = 1;

    public string AgentName { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string Output { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
