using System.ComponentModel.DataAnnotations;

namespace SmartVirtualBranch.Models;

/// <summary>
/// A historical CLOSED complaint uploaded by staff (one at a time, or in bulk via CSV) purely to
/// grow the Pattern Resolution Agent's precedent library. These are not live customer cases - they
/// never appear in Complaint Tracking, have no timeline, and are only ever read by
/// <c>ComplaintAgentPipelineService.FindPatternResolution</c> alongside real Closed complaints when
/// it looks for a matching keyword pattern for a brand-new case.
///
/// This is what lets the Pattern Resolution Agent "learn" from complaints that were resolved before
/// this platform existed - upload the old issue + how it was fixed, and any future case with an
/// overlapping description can be auto-drafted from it.
/// </summary>
public class KnowledgeBaseCase
{
    public int Id { get; set; }

    public string ReferenceCode { get; set; } = "KB-" + Guid.NewGuid().ToString("N")[..6].ToUpper();

    [Required(ErrorMessage = "Choose the product line this case belongs to.")]
    [Display(Name = "Product line / Category")]
    public string Category { get; set; } = "General Banking";

    [Required(ErrorMessage = "Describe the original issue.")]
    [StringLength(1000, MinimumLength = 10, ErrorMessage = "Please provide 10-1000 characters.")]
    [Display(Name = "Original issue description")]
    public string IssueDescription { get; set; } = string.Empty;

    [Required(ErrorMessage = "Describe how it was resolved.")]
    [StringLength(1000, MinimumLength = 5, ErrorMessage = "Please provide 5-1000 characters.")]
    [Display(Name = "Resolution that was applied")]
    public string ResolutionApplied { get; set; } = string.Empty;

    public string UploadedBy { get; set; } = string.Empty;

    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;

    /// "Manual Entry" or "CSV Bulk Upload"
    public string Source { get; set; } = "Manual Entry";

    /// How many live complaints this precedent has since been matched against by the
    /// Pattern Resolution Agent - a rough signal of how useful this upload has been.
    public int TimesMatched { get; set; }
}
