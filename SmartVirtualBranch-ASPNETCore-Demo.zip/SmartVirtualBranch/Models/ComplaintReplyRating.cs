using System.ComponentModel.DataAnnotations;

namespace SmartVirtualBranch.Models;

/// <summary>
/// A customer's star rating (1-5) of the AI-suggested resolution on their own case - i.e. feedback
/// on whatever the Pattern Resolution Agent / Resolution Agent drafted into
/// <see cref="Complaint.RootCauseSummary"/>. One rating per complaint; re-rating overwrites it.
/// This is the feedback loop back onto the Knowledge Base: consistently low-rated AI replies are a
/// signal that a precedent's drafted resolution needs a better human-authored one uploaded in its place.
/// </summary>
public class ComplaintReplyRating
{
    public int Id { get; set; }

    public int ComplaintId { get; set; }
    public Complaint? Complaint { get; set; }

    public string RatedByUserId { get; set; } = string.Empty;

    [Range(1, 5)]
    public int Stars { get; set; }

    [StringLength(500)]
    public string? Comment { get; set; }

    public DateTime RatedAt { get; set; } = DateTime.UtcNow;
}
