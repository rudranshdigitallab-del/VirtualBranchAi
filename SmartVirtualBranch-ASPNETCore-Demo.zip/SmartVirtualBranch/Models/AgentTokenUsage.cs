namespace SmartVirtualBranch.Models;

public record AgentUsageSummary(string Agent, int Calls, int PromptTokens, int CompletionTokens, int TotalTokens);

/// <summary>
/// One row per live Gemini call made by an agent. Only written when Live Mode is on and a
/// real API call was attempted - simulated/offline agent steps never write a usage row, so
/// this table is a true measurement of API consumption, not an estimate.
/// </summary>
public class AgentTokenUsage
{
    public int Id { get; set; }

    // Nullable: the Talking Agent can make a live call before any complaint exists yet
    // (e.g. the opening greeting, or a "no" response that never creates a case).
    public int? ComplaintId { get; set; }
    public Complaint? Complaint { get; set; }
    public string AgentName { get; set; } = string.Empty;

    /// Which text LLM served this call - "Gemini" or "Claude" - see ILlmProviderRouter.
    public string Provider { get; set; } = "Gemini";
    public string Model { get; set; } = string.Empty;
    public int PromptTokens { get; set; }
    public int CompletionTokens { get; set; }
    public int TotalTokens { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}
