# HDFC Smart Virtual Branch — ASP.NET Core Demo

A runnable ASP.NET Core 8 demo of the architecture in your diagram, focused on the
**Login / Authentication** layer (API Gateway & Security → Smart Virtual Branch Application Layer)
plus a simulated **AI Agents Orchestration Layer**.

> ⚠️ **Demo/prototype only.** All data, SLAs, policies and integrations are synthetic.
> There is no live LLM call by default (no API key needed) — the "AI Agent" pipeline is deterministic,
> rule-based C# so the whole thing runs **fully offline**. This is not an official HDFC Bank product.

## What's implemented

| Diagram layer | What this demo does |
|---|---|
| Channels | A single Website/Portal-style form lets you pick which channel a case "came from" (Website, Email, Chat, WhatsApp*, Voice*, Mobile App). |
| API Gateway & Security Layer | ASP.NET Core Identity — cookie auth, hashed passwords, `[Authorize]` / role checks stand in for JWT/OAuth2 + RBAC. |
| Smart Virtual Branch Application Layer | Dashboard tiles: Complaint Intake & Conversation, Customer 360 (via profile), Complaint Tracking, Escalation Workbench, SLA Monitor, Reports, Knowledge & Policies, Administration Console. |
| AI Agents Orchestration Layer | `ComplaintAgentPipelineService` runs **13 agents** across **9 phases** synchronously right after intake. Agents in the same phase have no dependency on each other and are dispatched with `Task.WhenAll` — **genuinely concurrent** when Live Mode is on, not just simulated timestamps: Investigation + Policy Intelligence + Pattern Resolution run together in Phase 5, and SLA + Escalation + Communication run together in Phase 7. A 14th agent, the Follow-Up Agent (Phase 10), then keeps running in the background for the case's whole lifetime — see **Real-Time Same-Day Resolution** below. |
| **Real-Time Same-Day Resolution (new)** | Every case gets a same-day resolution target, shown as a live countdown. Filing a complaint redirects instantly to the case page, where the 13-agent pipeline streams in live over SignalR instead of the browser waiting on one long request. A `CaseFollowUpBackgroundService` then watches every open case: if it goes quiet, the Follow-Up Agent nudges the assigned officer and proactively updates the customer; if the same-day target is genuinely at risk, it auto-escalates to the Branch Manager queue - no polling, everything pushes live. |
| **Expert Chat (new)** | On the case Details page, staff get a live chat with the "AI Case Agent" - it opens with a summary the moment triage finishes, and answers questions (policy citation, matched precedent, confidence, same-day status) straight from that case's own grounding facts, never inventing new ones. The Follow-Up Agent's nudges land in the same thread. |
| **Live LLM: Gemini or Claude (new)** | Every agent can call a real LLM to write its case note - an Administrator picks **Gemini** (Google's `generateContent` API) or **Claude** (Anthropic's `/v1/messages` API) on the AI Settings page. Routing/priority/SLA/pattern-match **decisions** always stay deterministic C# (reliable, reproducible, auditable) - the model's job is only to phrase that agent's explanation in natural language. If a live call fails, the app falls back to the deterministic text automatically. Anthropic has no public speech API, so Claude here is text-only, same as Gemini. |
| **Administrator control (new)** | Only the `Administrator` role can see and edit **AI Settings** (`/Admin/AiSettings`): turn Live Mode on/off, choose Gemini or Claude and set its API key/model, choose the speech engine (below), and set an optional cost-per-million-tokens rate. Everyone sees a small "🟢 Live \{Provider\} Agents" / "⚪ Simulated Agents" badge in the top nav so it's always clear which mode is active. |
| **Token utilization (new)** | Every live LLM call's token usage is saved to an `AgentTokenUsage` table (tagged with which provider served it). The Administration Console shows total calls, success/failure counts, tokens broken down by agent, and an optional estimated cost. Each case's Details page also shows its own token total and a 🟢 provider / ⚪ Simulated badge per agent card. Simulated (offline) steps never write a usage row, so the numbers you see are a real measurement, not an estimate. |
| Pattern Resolution Agent | Scans every **closed** case in the same product line for a matching keyword pattern. If it finds a strong precedent, it drafts an instant resolution citing the earlier case(s) and the complaint's status flips to **Auto-Resolved** — still held for a human agent to confirm before it can be formally Closed. |
| **Talking Agent / AI Branch Officer (new)** | A voice+chat front door at `/Talk`. The customer speaks (browser mic, Web Speech API) or types; the agent restates the issue, asks for a yes/no confirmation, then hands off into the same 14-agent pipeline and reads the outcome back out loud — all phrased in **Indian English** ("kindly", "sir/madam", "not to worry"). Deterministic templates guarantee a reply even offline; when Live Mode is on, the configured LLM only polishes that text's phrasing, never invents new facts. |
| **Real speech engine (new)** | Voice *replies* can use a real third-party TTS engine (ElevenLabs) instead of the browser's built-in voice, configured on AI Settings - `TalkController.Speak` calls it server-side so the API key never reaches the browser, and the client falls back to the browser's Web Speech API automatically if it's off or fails. Voice *input* (listening) always uses the browser's Web Speech API. |
| Integration & Data Access Layer | Mocked implicitly — the pipeline "reads" from fictitious Loan/Card/Payment/Transaction APIs in its generated text. |
| Roles (Channels/left panel personas) | `Customer`, `BranchOfficer`, `BranchManager`, `OperationsTeam`, `Administrator` — seeded automatically. |

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- No database server needed (uses EF Core's in-memory provider — data resets each time you restart the app)

## Run it

```bash
cd SmartVirtualBranch
dotnet restore
dotnet run
```

Then open the URL shown in the console (typically `https://localhost:5001` or `http://localhost:5000`).

By default the app runs entirely **offline in Simulated Mode** — no API key needed, nothing happens over the network.

## Turning on live LLM agents (Gemini or Claude)

1. Log in as `admin@demo.hdfcvb.com` (password `Demo@123`).
2. Open **AI Settings** in the top nav (Administrator-only).
3. Pick a **reasoning model**:
   - **Gemini**: get an API key from [Google AI Studio](https://aistudio.google.com/), paste it in, and check current [Gemini API docs](https://ai.google.dev/api/generate-content) for a valid model name.
   - **Claude**: get an API key from the [Claude Console](https://console.anthropic.com/), paste it in, and check current [Claude API docs](https://docs.claude.com/en/api/overview) for a valid model name (e.g. `claude-sonnet-5`).
4. Flip **Enable Live AI Agents** on and save.
5. File a new complaint (or open an existing one and re-run flows) — each agent's card on the case Details page will now show a 🟢 **\{Provider\} · N tokens** badge instead of ⚪ **Simulated**, and the Administration Console's **LLM Token Utilization** section will start filling in.

If a live call fails for any reason (bad key, network issue, rate limit, safety block), that agent's card automatically falls back to the same deterministic text used in Simulated Mode, with a note explaining why — the app never breaks because of an API problem. Turn Live Mode back off at any time to go fully offline again.

**Security note:** this demo stores API keys in the in-memory database only (wiped on restart, never written to disk) so it can be configured entirely inside the app. A production build should keep them in a secrets manager instead.

## Turning on real voice replies (ElevenLabs)

Anthropic doesn't publish a public speech API, so Claude above only ever writes text. For a more natural
spoken voice on the `/Talk` AI Branch Officer page (instead of the browser's built-in voice), an
Administrator can turn on a real third-party speech engine:

1. On **AI Settings**, under "Speech engine", get an API key from [elevenlabs.io](https://elevenlabs.io/) and paste it in.
2. Optionally set a specific voice ID from your ElevenLabs account (defaults to the public "Rachel" voice).
3. Switch the speech engine to **ElevenLabs** and save.

Voice *input* (listening to the customer) always uses the browser's built-in Web Speech API in this demo.
If ElevenLabs isn't configured or a call fails, spoken replies fall back to the browser's voice automatically.

## Demo logins

The app seeds five accounts on first run, plus one already-**closed** historical case and three new sample complaints. Password for all accounts: `Demo@123`

| Role | Email | What you'll see |
|---|---|---|
| Customer | `customer@demo.hdfcvb.com` | File a Complaint + track your own cases |
| Branch Officer | `officer@demo.hdfcvb.com` | Complaint Tracking + Resolve/Escalate actions |
| Branch Manager | `manager@demo.hdfcvb.com` | Same as officer, represents the escalation queue owner |
| Operations Team | `ops@demo.hdfcvb.com` | Read access to Complaint Tracking |
| Administrator | `admin@demo.hdfcvb.com` | Everything above + Administration Console (users, roles, all cases) |

The Login page also has one-click "Quick demo login" buttons that fill in each persona's email for you.

You can also self-register a new **Customer** account from the Login page ("Create an account").

## Try the flow

**Talk to the AI Branch Officer (new):**
1. Log in as `customer@demo.hdfcvb.com` and open **🎙️ Talk to AI Agent** in the nav (or the matching Dashboard tile).
2. Type (or tap the mic and speak) something like *"my UPI payment failed but money was deducted"*. The agent restates it back and asks you to confirm.
3. Reply "yes" — it registers the complaint through the same 14-agent pipeline, then reads back the reference number, category, priority and next steps in Indian English. If it matches a closed precedent, it reads back the drafted resolution instead.
4. Click **View my case** to land on the same Details page as every other complaint, or **Start a new conversation** to try again.
5. Toggle **🔊 Voice replies** on to have the agent speak its replies aloud (uses your browser's built-in text-to-speech - no audio is uploaded anywhere).

**See the Pattern Resolution Agent immediately (zero setup):**
1. Log in as `admin@demo.hdfcvb.com` (or `customer@demo.hdfcvb.com`) and open **Complaint Tracking**.
2. One seeded case is already marked **Auto-Resolved** — its EMI/overdue description matched a
   historical closed case seeded alongside it. Open it and expand the **Pattern Resolution Agent**
   card in Phase 5 to see the precedent it matched and the resolution it drafted.
3. Log in as `officer@demo.hdfcvb.com`, open that same case, and click **Confirm Auto-Resolution & Close**
   to finalize it as a human agent would.

**File a new complaint end to end:**
1. Log in as `customer@demo.hdfcvb.com`.
2. Click **File a Complaint**, describe an issue (e.g. *"I paid my EMI yesterday but my loan is still showing overdue"*), and submit.
3. You'll land on the case's **AI Agent Orchestration Timeline** — 9 phases, each with a simulated agent output, an auto-set priority/category, and a demo SLA due time. Phase 5 shows three agent cards side by side (Investigation, Policy Intelligence, Pattern Resolution) to represent parallel dispatch. Click "Prompt used by this agent" on any card to see its exact instructions.
4. Because this description matches the EMI/overdue precedent, this case should also come back **Auto-Resolved** — try describing something unrelated (e.g. a UPI transfer issue) to see the standard, non-pattern-matched path instead.
5. Visit **Agent Prompt Library** in the top nav (or the "How the AI Works" tile) to see all 14 agents, grouped by phase, with their full system prompts.
6. Log out, log back in as `officer@demo.hdfcvb.com`, open **Complaint Tracking**, open a case, and click **Resolve** or **Escalate** to see role-gated actions.
7. Log in as `admin@demo.hdfcvb.com` to see the **Administration Console** (all users/roles + every case).

## Project layout

```
Areas/Identity/Pages/Account/   Login, Register, Logout, AccessDenied (Razor Pages)
Controllers/                    Dashboard, Complaints, Admin, Agents, Talk, Home
Data/                           EF Core DbContext + demo seed data
Models/                         ApplicationUser, Complaint, ComplaintTimelineEvent, AgentCatalog,
                                 PlatformSettings, AgentTokenUsage
Services/                       ComplaintAgentPipelineService (orchestrator), GeminiAgentClient /
                                 ClaudeAgentClient (live LLM calls) + LlmProviderRouter (picks
                                 between them), ElevenLabsSpeechClient (real TTS), PlatformSettingsService
                                 (admin config), TalkingAgentService (voice/chat conversation state machine)
Views/                          Razor views (Bootstrap 5 via CDN)
wwwroot/css/site.css            Theming matching the diagram's blue/purple/green palette
```

## Extending toward the full architecture

To move this from demo to production-shaped, the most direct next steps mirror the diagram:

- Swap `UseInMemoryDatabase` for SQL Server / Postgres and split into real Customer/Account/Loan/Card/Payment/Transaction/CRM/Fraud/Complaint APIs.
- Move the LLM and speech API keys out of the database and into a secrets manager (Azure Key Vault, AWS Secrets Manager, `dotnet user-secrets` for local dev).
- Have the Policy Intelligence Agent ground its answers in a real RAG/vector store instead of the single hardcoded demo policy line.
- Let agents return structured JSON (Gemini's function-calling / Claude's tool use / JSON mode) so the LLM can influence routing/priority decisions directly, instead of only writing the narrative on top of deterministic rules.
- Add the API Gateway concerns explicitly (rate limiting, JWT/OAuth2, threat protection) if this sits behind a real gateway like YARP/Azure API Management.
- Wire notification/SMS/email channels for the Communication Agent.
- Add Prometheus/ELK-style monitoring and CI/CD once containerized (Docker/Kubernetes).
