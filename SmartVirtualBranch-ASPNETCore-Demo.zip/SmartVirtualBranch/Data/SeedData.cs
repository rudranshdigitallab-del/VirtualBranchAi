using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Models;
using SmartVirtualBranch.Services;

namespace SmartVirtualBranch.Data;

public static class SeedData
{
    public static readonly (string Email, string FullName, string Role, string Department)[] DemoAccounts =
    {
        ("customer@demo.hdfcvb.com", "Aarav Mehta",     "Customer",       "Retail Customer"),
        ("officer@demo.hdfcvb.com",  "Priya Nair",       "BranchOfficer",  "Branch Operations"),
        ("manager@demo.hdfcvb.com",  "Rohan Kapoor",     "BranchManager",  "Branch Management"),
        ("ops@demo.hdfcvb.com",      "Ishaan Verma",     "OperationsTeam", "Central Operations"),
        ("admin@demo.hdfcvb.com",    "Sana Deshmukh",    "Administrator",  "Platform Administration"),
    };

    public const string DemoPassword = "Demo@123";

    public static async Task InitializeAsync(IServiceProvider services)
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        await context.Database.EnsureCreatedAsync();

        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var pipeline = services.GetRequiredService<IComplaintAgentPipelineService>();

        foreach (var (_, _, role, _) in DemoAccounts)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

        var createdUsers = new Dictionary<string, ApplicationUser>();

        foreach (var (email, fullName, role, department) in DemoAccounts)
        {
            var existing = await userManager.FindByEmailAsync(email);
            if (existing != null)
            {
                createdUsers[role] = existing;
                continue;
            }

            var user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                EmailConfirmed = true,
                FullName = fullName,
                Department = department
            };

            var result = await userManager.CreateAsync(user, DemoPassword);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(user, role);
                createdUsers[role] = user;
            }
        }

        if (!context.Complaints.Any() && createdUsers.TryGetValue("Customer", out var customer))
        {
            // Seed one already-closed historical case first so the new Pattern Resolution Agent
            // has a real precedent to match against right out of the box.
            var historical = new Complaint
            {
                CustomerUserId = customer.Id,
                CustomerName = customer.FullName,
                ChannelSource = "Website / Portal",
                Description = "My EMI payment was deducted last week but the loan account still shows overdue status.",
                Category = "Auto-detect",
                CreatedAt = DateTime.UtcNow.AddDays(-10)
            };
            context.Complaints.Add(historical);
            await context.SaveChangesAsync();

            var historicalEvents = await pipeline.RunPipelineAsync(historical);
            foreach (var ev in historicalEvents)
            {
                ev.ComplaintId = historical.Id;
                context.ComplaintTimelineEvents.Add(ev);
            }

            // Simulate this case having already been resolved and closed by a human agent in the past.
            historical.Status = "Closed";
            historical.RootCauseSummary = "Reconciliation lag confirmed between the Payment API and Loan API; the overdue flag was manually cleared by a Branch Officer and no penalty was charged.";
            historical.AssignedOfficer = "Priya Nair";
            await context.SaveChangesAsync();

            var samples = new[]
            {
                "I paid my EMI yesterday but my personal loan is still showing overdue.",
                "I see a payment of Rs 2,499 on my credit card that I never made.",
                "My UPI transfer to a friend failed but the amount was deducted from my account."
            };
            var channels = new[] { "Website / Portal", "WhatsApp (Future)", "Mobile App" };

            Complaint? autoResolvedSample = null;

            for (int i = 0; i < samples.Length; i++)
            {
                var complaint = new Complaint
                {
                    CustomerUserId = customer.Id,
                    CustomerName = customer.FullName,
                    ChannelSource = channels[i],
                    Description = samples[i],
                    Category = "Auto-detect",
                    CreatedAt = DateTime.UtcNow.AddHours(-6 * (i + 1))
                };

                context.Complaints.Add(complaint);
                await context.SaveChangesAsync();

                var events = await pipeline.RunPipelineAsync(complaint);
                foreach (var ev in events)
                {
                    ev.ComplaintId = complaint.Id;
                    context.ComplaintTimelineEvents.Add(ev);
                }
                await context.SaveChangesAsync();

                if (complaint.Status == "Auto-Resolved" && autoResolvedSample == null)
                {
                    autoResolvedSample = complaint;
                }
            }

            // Demo rating from the customer on the one case the Pattern Resolution Agent auto-drafted,
            // so the Administration Console's feedback panel isn't empty on first run.
            if (autoResolvedSample != null)
            {
                context.ComplaintReplyRatings.Add(new ComplaintReplyRating
                {
                    ComplaintId = autoResolvedSample.Id,
                    RatedByUserId = customer.Id,
                    Stars = 5,
                    Comment = "Super fast - matched my case to a similar one and I didn't have to explain everything again.",
                    RatedAt = DateTime.UtcNow.AddHours(-5)
                });
                await context.SaveChangesAsync();
            }
        }

        // Seed the Closed Complaints Knowledge Base with a couple of pre-platform precedents so the
        // Pattern Resolution Agent (and the /KnowledgeBase module) have something to show immediately.
        if (!context.KnowledgeBaseCases.Any() && createdUsers.TryGetValue("Administrator", out var admin))
        {
            context.KnowledgeBaseCases.AddRange(
                new KnowledgeBaseCase
                {
                    Category = "Card",
                    IssueDescription = "Customer disputed a Rs 499 charge on their credit card statement that they didn't recognize.",
                    ResolutionApplied = "Charge was traced to an auto-renewed OTT subscription; refunded in full and the subscription was cancelled on the customer's behalf.",
                    UploadedBy = admin.FullName,
                    UploadedAt = DateTime.UtcNow.AddDays(-30),
                    Source = "Manual Entry"
                },
                new KnowledgeBaseCase
                {
                    Category = "Payment",
                    IssueDescription = "NEFT transfer showed as stuck in processing for three days and the customer wanted to know where the money was.",
                    ResolutionApplied = "Beneficiary bank's IFSC code on file was outdated; corrected it and the transfer completed within 24 hours, no charges applied.",
                    UploadedBy = admin.FullName,
                    UploadedAt = DateTime.UtcNow.AddDays(-18),
                    Source = "CSV Bulk Upload"
                });
            await context.SaveChangesAsync();
        }
    }
}
