using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Complaint> Complaints => Set<Complaint>();
    public DbSet<ComplaintTimelineEvent> ComplaintTimelineEvents => Set<ComplaintTimelineEvent>();
    public DbSet<PlatformSettings> PlatformSettings => Set<PlatformSettings>();
    public DbSet<AgentTokenUsage> AgentTokenUsages => Set<AgentTokenUsage>();
    public DbSet<KnowledgeBaseCase> KnowledgeBaseCases => Set<KnowledgeBaseCase>();
    public DbSet<ComplaintReplyRating> ComplaintReplyRatings => Set<ComplaintReplyRating>();
    public DbSet<ExpertChatMessage> ExpertChatMessages => Set<ExpertChatMessage>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Complaint>()
            .HasMany(c => c.TimelineEvents)
            .WithOne(e => e.Complaint)
            .HasForeignKey(e => e.ComplaintId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<AgentTokenUsage>()
            .HasOne(u => u.Complaint)
            .WithMany()
            .HasForeignKey(u => u.ComplaintId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<ComplaintReplyRating>()
            .HasOne(r => r.Complaint)
            .WithMany()
            .HasForeignKey(r => r.ComplaintId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<ComplaintReplyRating>()
            .HasIndex(r => r.ComplaintId)
            .IsUnique();

        builder.Entity<ExpertChatMessage>()
            .HasOne(m => m.Complaint)
            .WithMany()
            .HasForeignKey(m => m.ComplaintId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
