namespace SmartVirtualBranch.Services;

public interface IClaudeAgentClient
{
    Task<LlmAgentResult> InvokeAgentAsync(
        string systemPrompt,
        string userMessage,
        string model,
        string apiKey,
        CancellationToken cancellationToken = default);
}
