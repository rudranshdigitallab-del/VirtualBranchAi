namespace SmartVirtualBranch.Services;

public interface IGeminiAgentClient
{
    Task<LlmAgentResult> InvokeAgentAsync(
        string systemPrompt,
        string userMessage,
        string model,
        string apiKey,
        CancellationToken cancellationToken = default);
}
