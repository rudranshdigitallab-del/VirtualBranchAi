using System.Text;
using System.Text.Json;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Thin wrapper around ElevenLabs' text-to-speech REST endpoint.
/// https://elevenlabs.io/docs/api-reference/text-to-speech - verify the endpoint/model id against
/// current ElevenLabs docs, since both can change over time. The API key never leaves the server -
/// TalkController.Speak calls this and streams the resulting audio bytes back to the browser, so a
/// visitor's browser never sees the ElevenLabs key.
/// </summary>
public class ElevenLabsSpeechClient : IElevenLabsSpeechClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<ElevenLabsSpeechClient> _logger;

    public ElevenLabsSpeechClient(IHttpClientFactory httpClientFactory, ILogger<ElevenLabsSpeechClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task<SpeechSynthesisResult> SynthesizeAsync(string text, string voiceId, string apiKey, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            return new SpeechSynthesisResult(false, null, "No ElevenLabs API key is configured.");
        }
        if (string.IsNullOrWhiteSpace(voiceId))
        {
            voiceId = "21m00Tcm4TlvDq8ikWAM";
        }
        if (string.IsNullOrWhiteSpace(text))
        {
            return new SpeechSynthesisResult(false, null, "No text was provided to speak.");
        }

        // ElevenLabs bills per character - keep a sane cap so a runaway reply can't rack up cost.
        if (text.Length > 1200)
        {
            text = text[..1200];
        }

        try
        {
            var client = _httpClientFactory.CreateClient("elevenlabs");
            var url = $"https://api.elevenlabs.io/v1/text-to-speech/{Uri.EscapeDataString(voiceId)}";

            var payload = new
            {
                text,
                model_id = "eleven_multilingual_v2",
                voice_settings = new { stability = 0.5, similarity_boost = 0.75 }
            };

            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("xi-api-key", apiKey);
            request.Headers.Add("Accept", "audio/mpeg");
            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            using var response = await client.SendAsync(request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await response.Content.ReadAsStringAsync(cancellationToken);
                var snippet = errorBody.Length > 300 ? errorBody[..300] + "..." : errorBody;
                _logger.LogWarning("ElevenLabs API call failed with {StatusCode}: {Body}", response.StatusCode, snippet);
                return new SpeechSynthesisResult(false, null, $"HTTP {(int)response.StatusCode}: {snippet}");
            }

            var audioBytes = await response.Content.ReadAsByteArrayAsync(cancellationToken);
            if (audioBytes.Length == 0)
            {
                return new SpeechSynthesisResult(false, null, "ElevenLabs returned an empty audio response.");
            }

            return new SpeechSynthesisResult(true, audioBytes, null);
        }
        catch (TaskCanceledException)
        {
            return new SpeechSynthesisResult(false, null, "The ElevenLabs API call timed out.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error calling the ElevenLabs API.");
            return new SpeechSynthesisResult(false, null, ex.Message);
        }
    }
}
