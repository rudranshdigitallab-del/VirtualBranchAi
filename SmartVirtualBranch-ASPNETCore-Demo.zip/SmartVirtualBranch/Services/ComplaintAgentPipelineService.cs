using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Runs the "AI Agents Orchestration Layer" from the architecture diagram.
///
/// Design: the CASE FACTS (category, priority, SLA due time, pattern-match decision) are always
/// computed by fast, deterministic C# rules - this keeps routing/SLA/escalation behaviour reliable
/// and reproducible even if the LLM is unavailable, slow, or returns something unexpected.
/// The configured LLM provider (Gemini or Claude - see ILlmProviderRouter, chosen by an
/// Administrator on the AI Settings page) is used to WRITE each agent's case note in natural
/// language from those facts - the model explains, the rules decide. If a live call fails for any
/// reason, the deterministic fact text is shown instead with a clear "[unavailable]" note, so the
/// app never breaks because of a network problem.
///
/// Agents in the same Phase have no dependency on one another. When Live Mode is on, those agents
/// are dispatched with Task.WhenAll and genuinely run concurrently against the live API (not just
/// simulated timestamps) - literally side by side.
/// </summary>
public class ComplaintAgentPipelineService : IComplaintAgentPipelineService
{
    private readonly ApplicationDbContext _context;
    private readonly ILlmProviderRouter _llmRouter;
    private readonly IPlatformSettingsService _settingsService;

    public ComplaintAgentPipelineService(
        ApplicationDbContext context,
        ILlmProviderRouter llmRouter,
        IPlatformSettingsService settingsService)
    {
        _context = context;
        _llmRouter = llmRouter;
        _settingsService = settingsService;
    }

    private record AgentStepResult(
        string Agent, int Phase, string Action, string Output,
        int PromptTokens, int CompletionTokens, int TotalTokens, bool WasLiveAttempt, string? Error);

    public async Task<List<ComplaintTimelineEvent>> RunPipelineAsync(Complaint complaint, ICaseRealtimeNotifier? notifier = null)
    {
        var settings = await _settingsService.GetAsync();
        var text = (complaint.Description ?? string.Empty).ToLowerInvariant();

        if (string.IsNullOrWhiteSpace(complaint.Category) || complaint.Category == "Auto-detect")
        {
            complaint.Category = DetectCategory(text);
        }

        var priority = text.Contains("fraud") || text.Contains("unauthorized") ? "Critical"
            : (text.Contains("emi") || text.Contains("overdue") || text.Contains("charge") || text.Contains("charged")) ? "High"
            : "Medium";
        complaint.Priority = priority;

        var slaHours = priority switch
        {
            "Critical" => 4,
            "High" => 24,
            _ => 72
        };
        complaint.SlaDueAt = complaint.CreatedAt.AddHours(slaHours);

        // The same-day resolution promise this whole real-time module is built around - end of the
        // calendar day the case was filed, independent of the priority-scaled SlaDueAt above.
        if (complaint.SameDayTargetAt == default)
        {
            complaint.SameDayTargetAt = complaint.CreatedAt.Date.AddHours(23).AddMinutes(59);
        }

        var seed = complaint.Id == 0 ? complaint.ComplaintReference.GetHashCode() : complaint.Id;
        complaint.AiConfidenceScore = Math.Round(new Random(seed).NextDouble() * 0.15 + 0.82, 2);

        var events = new List<ComplaintTimelineEvent>();
        var order = 0;

        async Task<AgentStepResult> ComputeAsync(string agent, int phase, string action, string groundingFacts)
        {
            if (settings.LiveModeEnabled && _llmRouter.IsConfigured(settings))
            {
                var systemPrompt = AgentCatalog.GetPrompt(agent);
                var userMessage =
                    "Case grounding facts, already determined by the platform's deterministic banking logic - " +
                    "do not contradict or invent new facts, just explain these in your own words as this agent's case note " +
                    "(2-4 sentences, professional banking case-management tone):\n" + groundingFacts;

                var result = await _llmRouter.InvokeAsync(systemPrompt, userMessage, settings);

                if (result.Success)
                {
                    return new AgentStepResult(agent, phase, action, result.OutputText,
                        result.PromptTokens, result.CompletionTokens, result.TotalTokens, true, null);
                }

                return new AgentStepResult(agent, phase, action,
                    $"{groundingFacts} [{settings.LlmProvider} live call unavailable - showing deterministic fallback. {result.ErrorMessage}]",
                    0, 0, 0, true, result.ErrorMessage);
            }

            // Simulated mode has no network call to wait on, but the whole point of this module is
            // that agents feel like they're genuinely working in real time rather than teleporting
            // an answer - a short, deliberate pacing delay stands in for that "thinking" time.
            await Task.Delay(320);
            return new AgentStepResult(agent, phase, action, groundingFacts, 0, 0, 0, false, null);
        }

        async Task RecordAsync(AgentStepResult r)
        {
            order++;
            var ev = new ComplaintTimelineEvent
            {
                StepOrder = order,
                Phase = r.Phase,
                AgentName = r.Agent,
                Action = r.Action,
                Output = r.Output,
                Timestamp = DateTime.UtcNow
            };
            events.Add(ev);

            if (r.WasLiveAttempt)
            {
                _context.AgentTokenUsages.Add(new AgentTokenUsage
                {
                    ComplaintId = complaint.Id,
                    AgentName = r.Agent,
                    Provider = settings.LlmProvider,
                    Model = _llmRouter.ActiveModelName(settings),
                    PromptTokens = r.PromptTokens,
                    CompletionTokens = r.CompletionTokens,
                    TotalTokens = r.TotalTokens,
                    Success = r.Error == null,
                    ErrorMessage = r.Error,
                    Timestamp = DateTime.UtcNow
                });
            }

            if (notifier != null && complaint.Id != 0)
            {
                await notifier.TimelineEventAddedAsync(complaint.Id, ev);
            }
        }

        // Phase 1-4: strictly sequential, each depends on the previous agent's output.
        await RecordAsync(await ComputeAsync("Intake Agent", 1, "Case captured",
            $"Case opened via {complaint.ChannelSource}. Reference {complaint.ComplaintReference} assigned."));

        await RecordAsync(await ComputeAsync("Intent Agent", 2, "Intent classified", DetectIntent(text)));

        await RecordAsync(await ComputeAsync("Product Classification Agent", 3, "Product line mapped",
            $"Routed to the {complaint.Category} product team."));

        await RecordAsync(await ComputeAsync("Customer Context Agent", 4, "360° profile built",
            $"Pulled Customer, Account and Transaction records for {complaint.CustomerName} from mock core banking APIs."));

        // Phase 5: fan-out - Investigation, Policy Intelligence and Pattern Resolution all fired
        // concurrently (Task.WhenAll), each fed only by Customer Context.
        var (patternFound, matchedRefs, draftResolution) = FindPatternResolution(complaint);

        var phase5Specs = new (string Agent, string Action, string Facts)[]
        {
            ("Investigation Agent", "Systems of record checked", InvestigationNote(text, complaint.Category)),
            ("Policy Intelligence Agent", "Policy retrieved",
                $"Matched a {complaint.Category} resolution policy from the RAG / Vector Store with cited clause. [DEMO POLICY - not an actual bank policy]"),
            ("Pattern Resolution Agent", patternFound ? "Precedent pattern matched" : "No precedent pattern found",
                patternFound
                    ? $"Found {matchedRefs.Count} closed case(s) with a matching pattern ({string.Join(", ", matchedRefs)}). {draftResolution}"
                    : $"Scanned closed {complaint.Category} cases - no sufficiently similar precedent was found. This case proceeds through the standard Investigation + Policy Intelligence path."),
        };

        var phase5Results = await Task.WhenAll(phase5Specs.Select(s => ComputeAsync(s.Agent, 5, s.Action, s.Facts)));
        foreach (var r in phase5Results) await RecordAsync(r);

        // Phase 6: join - Resolution Agent waits for all three phase 5 agents to finish.
        await RecordAsync(await ComputeAsync("Resolution Agent", 6, "Resolution recommended",
            patternFound
                ? $"Adopted the Pattern Resolution Agent's draft: {draftResolution} Marked as an auto-drafted resolution pending human confirmation."
                : ResolutionNote(text, complaint.Category)));

        // Phase 7: fan-out - SLA, Escalation and Communication all fired concurrently off the Resolution Agent's output.
        var phase7Specs = new (string Agent, string Action, string Facts)[]
        {
            ("SLA Agent", "SLA calculated",
                $"Priority set to {priority}. Demo SLA due by {complaint.SlaDueAt:dd-MMM-yyyy HH:mm} UTC (illustrative only, not an actual bank SLA)."),
            ("Escalation Agent", "Breach risk scored",
                patternFound
                    ? "Resolution already drafted from a matched precedent - routed straight to human confirmation instead of the escalation queue."
                    : priority == "Critical"
                        ? "High breach probability -> auto-escalated to the Branch Manager queue pending human approval."
                        : "Within the SLA envelope -> retained in the Branch Officer queue."),
            ("Communication Agent", "Customer update drafted",
                $"Drafted an acknowledgement for the {complaint.ChannelSource} channel. Held for human approval before sending."),
        };

        var phase7Results = await Task.WhenAll(phase7Specs.Select(s => ComputeAsync(s.Agent, 7, s.Action, s.Facts)));
        foreach (var r in phase7Results) await RecordAsync(r);

        // Phase 8: join - Closure Agent. Closure never happens automatically in this demo - even a
        // pattern-matched resolution waits for a human to confirm it via the Resolve action.
        await RecordAsync(await ComputeAsync("Closure Agent", 8,
            patternFound ? "Draft resolution ready for sign-off" : "Awaiting closure",
            patternFound
                ? "An auto-drafted resolution from the Pattern Resolution Agent is ready. A human agent must confirm it before the case is formally closed."
                : "Case remains open until a human agent confirms the resolution and closes it with a full audit trail."));

        // Phase 9: background agent, not on the customer-facing critical path.
        await RecordAsync(await ComputeAsync("Root Cause Analysis Agent", 9, "Logged for trend analysis",
            patternFound
                ? $"Reinforced the existing '{complaint.Category}' pattern (now matched across {matchedRefs.Count + 1} cases) for the weekly Root Cause & Prevention report."
                : $"Tagged as a '{complaint.Category}' pattern and added to the weekly Root Cause & Prevention report."));

        if (patternFound)
        {
            complaint.Status = "Auto-Resolved";
            complaint.AssignedOfficer = "Pattern Resolution Agent (pending confirmation)";
            complaint.RootCauseSummary = draftResolution;
        }
        else
        {
            complaint.Status = priority == "Critical" ? "Escalated" : "In Progress";
            complaint.AssignedOfficer = priority == "Critical" ? "Branch Manager Queue" : "Branch Officer Queue";
        }

        if (notifier != null && complaint.Id != 0)
        {
            await notifier.StatusChangedAsync(complaint.Id, complaint.Status, complaint.Priority, complaint.AssignedOfficer);
        }

        return events;
    }

    public async Task PostInitialExpertChatSummaryAsync(Complaint complaint, ICaseRealtimeNotifier? notifier = null)
    {
        var settings = await _settingsService.GetAsync();

        var deterministicSummary =
            $"New case {complaint.ComplaintReference} - {complaint.Category}, {complaint.Priority} priority, " +
            $"{(complaint.AiConfidenceScore * 100):0}% AI confidence. " +
            (complaint.Status == "Auto-Resolved"
                ? $"I found a matching precedent and drafted a resolution: {complaint.RootCauseSummary} It's ready for your confirmation."
                : $"No precedent match, so this needs a first-principles review. Routed to {complaint.AssignedOfficer}.") +
            $" Same-day target: {complaint.SameDayTargetAt:HH:mm} today. Reply here anytime - I can pull the policy citation, matched precedent, or a full recap.";

        var message = deterministicSummary;

        if (settings.LiveModeEnabled && _llmRouter.IsConfigured(settings))
        {
            var systemPrompt = AgentCatalog.GetPrompt("Follow-Up Agent (Real-Time Monitoring)");
            var userMessage =
                "Case grounding facts, already determined by deterministic banking logic - do not contradict or invent new " +
                "facts, just phrase this as your opening message to the assigned officer in the Expert Chat " +
                "(2-4 sentences, direct and professional, addressed to a colleague not the customer):\n" + deterministicSummary;

            var result = await _llmRouter.InvokeAsync(systemPrompt, userMessage, settings);
            if (result.Success && !string.IsNullOrWhiteSpace(result.OutputText))
            {
                message = result.OutputText;
            }

            _context.AgentTokenUsages.Add(new AgentTokenUsage
            {
                ComplaintId = complaint.Id,
                AgentName = "Follow-Up Agent (Real-Time Monitoring)",
                Provider = settings.LlmProvider,
                Model = _llmRouter.ActiveModelName(settings),
                PromptTokens = result.PromptTokens,
                CompletionTokens = result.CompletionTokens,
                TotalTokens = result.TotalTokens,
                Success = result.Success,
                ErrorMessage = result.ErrorMessage,
                Timestamp = DateTime.UtcNow
            });
        }

        var chatMessage = new ExpertChatMessage
        {
            ComplaintId = complaint.Id,
            SenderType = "AI",
            SenderName = "AI Case Agent",
            Message = message,
            Timestamp = DateTime.UtcNow
        };
        _context.ExpertChatMessages.Add(chatMessage);
        await _context.SaveChangesAsync();

        if (notifier != null)
        {
            await notifier.ExpertChatMessageAddedAsync(complaint.Id, chatMessage);
        }
    }

    /// <summary>
    /// A single candidate precedent the Pattern Resolution Agent can match against, unifying two
    /// sources: real Closed complaints handled on this platform, and historical cases staff have
    /// uploaded into the Closed Complaints Knowledge Base (<see cref="KnowledgeBaseCase"/>) purely to
    /// teach the agent about issues resolved before the platform existed.
    /// </summary>
    private record PrecedentCandidate(string Reference, string Description, string? Resolution, bool FromKnowledgeBase, int? KnowledgeBaseCaseId);

    /// <summary>
    /// The Pattern Resolution Agent's matching logic: look at every CLOSED case in the same product
    /// line - both real closed complaints AND staff-uploaded Knowledge Base precedents - compare
    /// significant keywords in the description, and treat 2+ shared keywords as a "matching pattern".
    /// This stays deterministic (no LLM call) so pattern-match decisions are stable and auditable;
    /// only the narrative explanation of the match goes through Gemini.
    /// </summary>
    private (bool Found, List<string> MatchedReferences, string Draft) FindPatternResolution(Complaint complaint)
    {
        var candidateWords = ExtractKeywords(complaint.Description);
        if (candidateWords.Count == 0)
        {
            return (false, new List<string>(), string.Empty);
        }

        var priorClosedCases = _context.Complaints
            .Where(c => c.Status == "Closed" && c.Id != complaint.Id && c.Category == complaint.Category)
            .ToList()
            .Select(c => new PrecedentCandidate(c.ComplaintReference, c.Description, c.RootCauseSummary, false, null));

        var knowledgeBaseCases = _context.KnowledgeBaseCases
            .Where(k => k.Category == complaint.Category)
            .ToList()
            .Select(k => new PrecedentCandidate(k.ReferenceCode, k.IssueDescription, k.ResolutionApplied, true, k.Id));

        var allCandidates = priorClosedCases.Concat(knowledgeBaseCases).ToList();

        var scored = new List<(PrecedentCandidate Candidate, int Score)>();
        foreach (var candidate in allCandidates)
        {
            var overlap = candidateWords.Intersect(ExtractKeywords(candidate.Description)).Count();
            if (overlap >= 2)
            {
                scored.Add((candidate, overlap));
            }
        }

        if (scored.Count == 0)
        {
            return (false, new List<string>(), string.Empty);
        }

        var best = scored.OrderByDescending(s => s.Score).Take(3).ToList();
        var refs = best.Select(s => s.Candidate.Reference).ToList();
        var top = best.First().Candidate;

        var precedentNote = top.Resolution;
        var sourceNote = best.Any(b => b.Candidate.FromKnowledgeBase)
            ? " (drawing on the Closed Complaints Knowledge Base)"
            : string.Empty;
        var draft = string.IsNullOrWhiteSpace(precedentNote)
            ? $"Recommend applying the same {complaint.Category} resolution playbook that closed the matched precedent case(s){sourceNote}."
            : $"Recommend applying the same fix as precedent case {top.Reference}{sourceNote}: {precedentNote}";

        // Track usage on any Knowledge Base entries that contributed, purely for the staff-facing
        // "times matched" signal - never affects the deterministic match decision itself.
        var matchedKbIds = best.Where(b => b.Candidate.FromKnowledgeBase).Select(b => b.Candidate.KnowledgeBaseCaseId!.Value).ToList();
        if (matchedKbIds.Count > 0)
        {
            var kbEntries = _context.KnowledgeBaseCases.Where(k => matchedKbIds.Contains(k.Id));
            foreach (var kb in kbEntries)
            {
                kb.TimesMatched++;
            }
        }

        return (true, refs, draft);
    }

    private static readonly HashSet<string> StopWords = new()
    {
        "the", "a", "an", "is", "was", "my", "i", "to", "and", "for", "on", "in", "of", "it",
        "this", "that", "with", "still", "not", "did", "have", "has", "but", "are", "am", "me",
        "been", "will", "be", "as", "at", "by", "from", "or", "so", "just", "please", "showing"
    };

    private static HashSet<string> ExtractKeywords(string? text) =>
        (text ?? string.Empty)
            .ToLowerInvariant()
            .Split(new[] { ' ', '.', ',', '!', '?', ';', ':' }, StringSplitOptions.RemoveEmptyEntries)
            .Where(w => w.Length > 3 && !StopWords.Contains(w))
            .ToHashSet();

    private static string DetectCategory(string text)
    {
        if (text.Contains("loan") || text.Contains("emi")) return "Loan";
        if (text.Contains("card")) return "Card";
        if (text.Contains("fraud") || text.Contains("unauthorized")) return "Fraud";
        if (text.Contains("payment") || text.Contains("upi") || text.Contains("transfer") || text.Contains("neft") || text.Contains("imps")) return "Payment";
        if (text.Contains("account") || text.Contains("balance") || text.Contains("statement")) return "Account";
        return "General Banking";
    }

    private static string DetectIntent(string text)
    {
        if (text.Contains("overdue") || text.Contains("still showing"))
            return "Customer disputes an account status that appears out of sync with a payment already made.";
        if (text.Contains("fraud") || text.Contains("unauthorized"))
            return "Customer is reporting a suspected unauthorized transaction.";
        if (text.Contains("charge") || text.Contains("charged"))
            return "Customer disputes a charge or fee applied to their account.";
        return "Customer is reporting a service issue that requires investigation and resolution.";
    }

    private static string InvestigationNote(string text, string category)
    {
        if (category == "Loan" && (text.Contains("emi") || text.Contains("overdue")))
            return "Mock Payment API shows the EMI credited at T+1; mock Loan API shows the overdue flag not yet cleared - a reconciliation lag was identified as the likely root cause.";
        if (category == "Fraud")
            return "Mock Transaction API and Fraud API flagged the transaction pattern for manual review; card temporarily marked for monitoring.";
        return $"Reviewed the {category} API and Transaction API records; no immediate discrepancy found beyond the customer-reported issue.";
    }

    private static string ResolutionNote(string text, string category)
    {
        if (category == "Loan" && (text.Contains("emi") || text.Contains("overdue")))
            return "Recommend triggering a manual reconciliation to clear the overdue flag and sending an apology communication. No penalty should be charged (pending human approval).";
        if (category == "Fraud")
            return "Recommend a temporary hold on the card, a dispute case with the Fraud team, and provisional credit pending investigation (pending human approval).";
        return $"Recommend the standard {category} resolution playbook; supporting evidence attached for officer review and approval.";
    }
}
