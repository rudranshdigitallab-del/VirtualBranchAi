using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Thin abstraction over SignalR so the pipeline, controllers and background monitor can push
/// live updates onto a case without taking a direct dependency on IHubContext. Every method is
/// "push and forget" - broadcasting is a courtesy to whoever's watching live, never the system of
/// record (the database write always happens first, separately).
/// </summary>
public interface ICaseRealtimeNotifier
{
    Task TimelineEventAddedAsync(int complaintId, ComplaintTimelineEvent ev);
    Task ExpertChatMessageAddedAsync(int complaintId, ExpertChatMessage message);
    Task StatusChangedAsync(int complaintId, string status, string priority, string assignedOfficer);
    Task ProcessingStartedAsync(int complaintId);
    Task ProcessingCompletedAsync(int complaintId, string redirectUrl);
}
