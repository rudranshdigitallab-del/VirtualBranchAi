using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// The "Follow-Up Agent (Real-Time Monitoring)" from <see cref="AgentCatalog"/>, running as an
/// always-on background service rather than a one-shot pipeline step. On a fixed tick it scans
/// every case that isn't Closed yet and:
///
///  1. Nudges the assigned officer in the Expert Chat, and posts a proactive customer-facing update,
///     if the case has gone quiet for too long.
///  2. Auto-escalates priority and routes to the Branch Manager queue if the same-day resolution
///     target is genuinely at risk and nobody has acted.
///
/// Every change here is pushed live over SignalR the moment it happens - this is what makes the
/// platform's "resolved the same day, with the AI actively chasing it" promise feel real rather than
/// just a label on the complaint.
///
/// DEMO SCALING NOTE: a real deployment would check these thresholds in hours against a real
/// same-day deadline. Waiting literal hours would make this feature invisible in a live demo, so the
/// idle/at-risk thresholds below are deliberately compressed to minutes - the mechanism is identical,
/// only the clock is sped up. See <c>IdleThreshold</c> / <c>EscalationAgeThreshold</c> below.
/// </summary>
public class CaseFollowUpBackgroundService : BackgroundService
{
    private static readonly TimeSpan TickInterval = TimeSpan.FromSeconds(20);
    private static readonly TimeSpan IdleThreshold = TimeSpan.FromSeconds(75);
    private static readonly TimeSpan FollowUpCooldown = TimeSpan.FromSeconds(90);
    private static readonly TimeSpan EscalationAgeThreshold = TimeSpan.FromMinutes(3);

    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<CaseFollowUpBackgroundService> _logger;

    public CaseFollowUpBackgroundService(IServiceScopeFactory scopeFactory, ILogger<CaseFollowUpBackgroundService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Give the app a moment to finish seeding before the first tick.
        try { await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken); } catch (TaskCanceledException) { return; }

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await TickAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Follow-Up Agent background tick failed.");
            }

            try { await Task.Delay(TickInterval, stoppingToken); } catch (TaskCanceledException) { break; }
        }
    }

    private async Task TickAsync(CancellationToken stoppingToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var notifier = scope.ServiceProvider.GetRequiredService<ICaseRealtimeNotifier>();

        var now = DateTime.UtcNow;

        var openCases = await context.Complaints
            .Where(c => c.Status != "Closed")
            .ToListAsync(stoppingToken);

        foreach (var complaint in openCases)
        {
            var lastActivity = await GetLastActivityAsync(context, complaint, stoppingToken);
            var quietFor = now - lastActivity;
            var age = now - complaint.CreatedAt;
            var alreadyNudgedRecently = complaint.LastFollowUpAt.HasValue && now - complaint.LastFollowUpAt.Value < FollowUpCooldown;

            var timeRemaining = complaint.SameDayTargetAt - now;
            var remainingLabel = timeRemaining.TotalMinutes > 0
                ? $"{(int)timeRemaining.TotalHours}h {timeRemaining.Minutes}m remaining to the same-day target"
                : "past the same-day target";

            // --- 1. Gentle nudge when a case has gone quiet ---
            // Skip cases still mid-pipeline ("Analyzing") - they haven't gone quiet, they're busy.
            if (complaint.Status != "Analyzing" && quietFor >= IdleThreshold && !alreadyNudgedRecently)
            {
                await PostNudgeAsync(context, notifier, complaint, remainingLabel, stoppingToken);
                complaint.LastFollowUpAt = now;
            }

            // --- 2. Auto-escalate if the same-day promise is genuinely at risk ---
            var stillUnresolved = complaint.Status is "New" or "In Progress";
            if (stillUnresolved && age >= EscalationAgeThreshold && complaint.Priority != "Critical")
            {
                await AutoEscalateAsync(context, notifier, complaint, stoppingToken);
            }

            await context.SaveChangesAsync(stoppingToken);
        }
    }

    private static async Task<DateTime> GetLastActivityAsync(ApplicationDbContext context, Complaint complaint, CancellationToken ct)
    {
        var lastTimelineAt = await context.ComplaintTimelineEvents
            .Where(e => e.ComplaintId == complaint.Id)
            .OrderByDescending(e => e.Timestamp)
            .Select(e => (DateTime?)e.Timestamp)
            .FirstOrDefaultAsync(ct);

        var lastChatAt = await context.ExpertChatMessages
            .Where(m => m.ComplaintId == complaint.Id)
            .OrderByDescending(m => m.Timestamp)
            .Select(m => (DateTime?)m.Timestamp)
            .FirstOrDefaultAsync(ct);

        var candidates = new[] { lastTimelineAt, lastChatAt, complaint.CreatedAt };
        return candidates.Where(c => c.HasValue).Select(c => c!.Value).DefaultIfEmpty(complaint.CreatedAt).Max();
    }

    private static async Task PostNudgeAsync(
        ApplicationDbContext context, ICaseRealtimeNotifier notifier, Complaint complaint, string remainingLabel, CancellationToken ct)
    {
        var officerMessage = new ExpertChatMessage
        {
            ComplaintId = complaint.Id,
            SenderType = "AI",
            SenderName = "Follow-Up Agent",
            Message = $"⏰ Case {complaint.ComplaintReference} has been quiet for a while - currently {complaint.Status} " +
                      $"in the {complaint.AssignedOfficer} queue, {remainingLabel}. Kindly action or leave an update when you get a moment.",
            Timestamp = DateTime.UtcNow
        };
        context.ExpertChatMessages.Add(officerMessage);
        await notifier.ExpertChatMessageAddedAsync(complaint.Id, officerMessage);

        var customerEvent = new ComplaintTimelineEvent
        {
            ComplaintId = complaint.Id,
            StepOrder = 900 + (int)(DateTime.UtcNow.Ticks % 90), // demo-only: keeps ordering roughly chronological without a DB round-trip
            Phase = 10,
            AgentName = "Follow-Up Agent (Real-Time Monitoring)",
            Action = "Proactive customer update",
            Output = $"We're still on it - your case is with {complaint.AssignedOfficer}, {remainingLabel}. " +
                     "We'll keep you posted and are targeting resolution today.",
            Timestamp = DateTime.UtcNow
        };
        context.ComplaintTimelineEvents.Add(customerEvent);
        await notifier.TimelineEventAddedAsync(complaint.Id, customerEvent);
    }

    private static async Task AutoEscalateAsync(
        ApplicationDbContext context, ICaseRealtimeNotifier notifier, Complaint complaint, CancellationToken ct)
    {
        complaint.Priority = "Critical";
        complaint.Status = "Escalated";
        complaint.AssignedOfficer = "Branch Manager Queue";

        var systemMessage = new ExpertChatMessage
        {
            ComplaintId = complaint.Id,
            SenderType = "System",
            SenderName = "Follow-Up Agent",
            Message = $"🚨 Auto-escalated to the Branch Manager queue - the same-day resolution target on {complaint.ComplaintReference} " +
                      "was at risk with no recent action. Priority raised to Critical.",
            Timestamp = DateTime.UtcNow
        };
        context.ExpertChatMessages.Add(systemMessage);
        await notifier.ExpertChatMessageAddedAsync(complaint.Id, systemMessage);

        var timelineEvent = new ComplaintTimelineEvent
        {
            ComplaintId = complaint.Id,
            StepOrder = 950 + (int)(DateTime.UtcNow.Ticks % 40),
            Phase = 7,
            AgentName = "Escalation Agent",
            Action = "Auto-escalated by Follow-Up Agent",
            Output = "No action recorded within the same-day monitoring window - automatically escalated to the Branch Manager queue and priority raised to Critical.",
            Timestamp = DateTime.UtcNow
        };
        context.ComplaintTimelineEvents.Add(timelineEvent);
        await notifier.TimelineEventAddedAsync(complaint.Id, timelineEvent);

        await notifier.StatusChangedAsync(complaint.Id, complaint.Status, complaint.Priority, complaint.AssignedOfficer);
    }
}
