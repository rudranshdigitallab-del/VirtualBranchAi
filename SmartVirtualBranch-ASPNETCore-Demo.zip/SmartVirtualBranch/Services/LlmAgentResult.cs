namespace SmartVirtualBranch.Services;

/// <summary>
/// Shared shape returned by every LLM client (Gemini, Claude, ...) so the orchestration pipeline,
/// Talking Agent and Expert Chat summarizer can call whichever provider is configured through the
/// same code path - see <see cref="ILlmProviderRouter"/>.
/// </summary>
public record LlmAgentResult(
    bool Success,
    string OutputText,
    int PromptTokens,
    int CompletionTokens,
    int TotalTokens,
    string? ErrorMessage);
