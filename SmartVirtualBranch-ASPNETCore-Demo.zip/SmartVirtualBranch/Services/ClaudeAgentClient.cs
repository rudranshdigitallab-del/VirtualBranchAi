using System.Text;
using System.Text.Json;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Thin wrapper around Anthropic's Messages API (https://api.anthropic.com/v1/messages), used as an
/// alternative to Gemini for the same "rules decide, the model explains" role throughout this app -
/// see ILlmProviderRouter for how the two are selected between.
///
/// NOTE: Anthropic does not publish a speech (STT/TTS) API for third-party integration - only the
/// text Messages API is called here. Voice I/O in this app is handled separately (browser
/// Web Speech API for input, optionally ElevenLabs for output - see ElevenLabsSpeechClient).
/// Verify the model name and endpoint version against current Anthropic API docs, since both can
/// change over time: https://docs.claude.com/en/api/overview
/// </summary>
public class ClaudeAgentClient : IClaudeAgentClient
{
    private const string ApiVersion = "2023-06-01";

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<ClaudeAgentClient> _logger;

    public ClaudeAgentClient(IHttpClientFactory httpClientFactory, ILogger<ClaudeAgentClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task<LlmAgentResult> InvokeAgentAsync(
        string systemPrompt,
        string userMessage,
        string model,
        string apiKey,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, "No Claude API key is configured.");
        }

        if (string.IsNullOrWhiteSpace(model))
        {
            model = "claude-sonnet-5";
        }

        try
        {
            var client = _httpClientFactory.CreateClient("claude");

            var payload = new
            {
                model,
                max_tokens = 400,
                temperature = 0.3,
                system = systemPrompt,
                messages = new[]
                {
                    new { role = "user", content = userMessage }
                }
            };

            using var request = new HttpRequestMessage(HttpMethod.Post, "https://api.anthropic.com/v1/messages");
            request.Headers.Add("x-api-key", apiKey);
            request.Headers.Add("anthropic-version", ApiVersion);
            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            using var response = await client.SendAsync(request, cancellationToken);
            var raw = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var errorSnippet = raw.Length > 300 ? raw[..300] + "..." : raw;
                _logger.LogWarning("Claude API call failed with {StatusCode}: {Body}", response.StatusCode, errorSnippet);
                return new LlmAgentResult(false, string.Empty, 0, 0, 0, $"HTTP {(int)response.StatusCode}: {errorSnippet}");
            }

            using var doc = JsonDocument.Parse(raw);
            var root = doc.RootElement;

            var text = new StringBuilder();
            if (root.TryGetProperty("content", out var contentBlocks) && contentBlocks.ValueKind == JsonValueKind.Array)
            {
                foreach (var block in contentBlocks.EnumerateArray())
                {
                    if (block.TryGetProperty("type", out var blockType) && blockType.GetString() == "text"
                        && block.TryGetProperty("text", out var blockText))
                    {
                        text.Append(blockText.GetString());
                    }
                }
            }

            var promptTokens = 0;
            var completionTokens = 0;

            if (root.TryGetProperty("usage", out var usage))
            {
                if (usage.TryGetProperty("input_tokens", out var it)) promptTokens = it.GetInt32();
                if (usage.TryGetProperty("output_tokens", out var ot)) completionTokens = ot.GetInt32();
            }
            var totalTokens = promptTokens + completionTokens;

            if (text.Length == 0)
            {
                return new LlmAgentResult(false, string.Empty, promptTokens, completionTokens, totalTokens,
                    "Claude returned an empty response (it may have been blocked, or hit max_tokens with no text yet).");
            }

            return new LlmAgentResult(true, text.ToString().Trim(), promptTokens, completionTokens, totalTokens, null);
        }
        catch (TaskCanceledException)
        {
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, "The Claude API call timed out.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error calling the Claude API.");
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, ex.Message);
        }
    }
}
