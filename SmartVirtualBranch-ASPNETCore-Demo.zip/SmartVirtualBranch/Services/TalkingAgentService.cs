using System.Text;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Drives the "Talking Agent (AI Branch Officer)" conversation: greet -> listen to the complaint
/// -> confirm -> hand off into the same 14-agent orchestration pipeline -> read the resolution
/// back. The conversation is intentionally stateless on the server (state + pendingMessage are
/// round-tripped from the client with each turn) so no session/cache setup is needed for the demo.
///
/// Every reply is built in Indian English first by deterministic templates (always available,
/// always reliable). When Live Mode + a Gemini key are configured, that deterministic text is sent
/// to Gemini only to be polished/rephrased - never to invent new facts - consistent with how the
/// rest of the orchestration layer uses the model to explain, not decide.
/// </summary>
public class TalkingAgentService : ITalkingAgentService
{
    private const string TalkingAgentName = "Talking Agent (AI Branch Officer)";

    private static readonly string[] AffirmativeWords =
        { "yes", "yeah", "yup", "sure", "go ahead", "please proceed", "confirm", "correct", "okay", "ok", "haan" };

    private static readonly string[] NegativeWords =
        { "no", "nahi", "cancel", "not now", "wait", "stop", "don't" };

    private readonly ApplicationDbContext _context;
    private readonly IComplaintAgentPipelineService _pipeline;
    private readonly ILlmProviderRouter _llmRouter;
    private readonly IPlatformSettingsService _settingsService;
    private readonly ICaseRealtimeNotifier _notifier;

    public TalkingAgentService(
        ApplicationDbContext context,
        IComplaintAgentPipelineService pipeline,
        ILlmProviderRouter llmRouter,
        IPlatformSettingsService settingsService,
        ICaseRealtimeNotifier notifier)
    {
        _context = context;
        _pipeline = pipeline;
        _llmRouter = llmRouter;
        _settingsService = settingsService;
        _notifier = notifier;
    }

    public async Task<TalkTurnResult> HandleTurnAsync(ApplicationUser user, string state, string message, string? pendingMessage, string channelSource)
    {
        message = (message ?? string.Empty).Trim();

        if (state == "awaiting_confirmation")
        {
            var lower = message.ToLowerInvariant();

            if (AffirmativeWords.Any(w => lower.Contains(w)))
            {
                var description = string.IsNullOrWhiteSpace(pendingMessage) ? message : pendingMessage;
                var complaint = await CreateAndProcessComplaintAsync(user, description, channelSource);

                var resolutionDraft = BuildResolutionReply(complaint);
                var resolutionReply = await PolishAsync(resolutionDraft, complaint.Id);

                return new TalkTurnResult("completed", resolutionReply, null, complaint.ComplaintReference, $"/Complaints/Details/{complaint.Id}");
            }

            if (NegativeWords.Any(w => lower.Contains(w)))
            {
                var draft = "No problem at all, sir/madam. I have not registered anything. Please describe your issue again whenever you are ready, I am very much here to help.";
                var reply = await PolishAsync(draft, null);
                return new TalkTurnResult("awaiting_complaint", reply, null, null, null);
            }

            var nudgeDraft = "Sorry, I could not understand that clearly. Kindly confirm with a simple 'yes' or 'no' - shall I go ahead and register this complaint?";
            var nudgeReply = await PolishAsync(nudgeDraft, null);
            return new TalkTurnResult("awaiting_confirmation", nudgeReply, pendingMessage, null, null);
        }

        // Default / "awaiting_complaint": the customer is describing their issue for the first time.
        if (string.IsNullOrWhiteSpace(message))
        {
            var draft = "Namaste! I am your AI Branch Officer here at Smart Virtual Branch. Please go ahead and tell me, what is the problem you are facing today?";
            var reply = await PolishAsync(draft, null);
            return new TalkTurnResult("awaiting_complaint", reply, null, null, null);
        }

        var confirmDraft = $"I understand, sir/madam. You are saying: \"{message}\". Shall I go ahead and register this complaint for you right away? Kindly reply yes or no.";
        var confirmReply = await PolishAsync(confirmDraft, null);
        return new TalkTurnResult("awaiting_confirmation", confirmReply, message, null, null);
    }

    private async Task<Complaint> CreateAndProcessComplaintAsync(ApplicationUser user, string description, string channelSource)
    {
        var complaint = new Complaint
        {
            CustomerUserId = user.Id,
            CustomerName = string.IsNullOrWhiteSpace(user.FullName) ? user.Email! : user.FullName,
            ChannelSource = channelSource,
            Description = description,
            Category = "Auto-detect",
            CreatedAt = DateTime.UtcNow
        };

        _context.Complaints.Add(complaint);
        await _context.SaveChangesAsync();

        var events = await _pipeline.RunPipelineAsync(complaint);
        foreach (var ev in events)
        {
            ev.ComplaintId = complaint.Id;
            _context.ComplaintTimelineEvents.Add(ev);
        }

        await _context.SaveChangesAsync();
        await _pipeline.PostInitialExpertChatSummaryAsync(complaint, _notifier);
        return complaint;
    }

    private static string BuildResolutionReply(Complaint complaint)
    {
        var sb = new StringBuilder();
        sb.Append("Thank you for your patience, sir/madam. I have registered your complaint successfully, reference number ")
          .Append(complaint.ComplaintReference).Append(". ");
        sb.Append("It has been classified under ").Append(complaint.Category)
          .Append(" with ").Append(complaint.Priority).Append(" priority. ");

        if (complaint.Status == "Auto-Resolved")
        {
            sb.Append("I have good news - a similar case was resolved before, so a resolution has already been drafted for you: ");
            sb.Append(complaint.RootCauseSummary).Append(' ');
            sb.Append("This is just pending final confirmation from our bank officer, after which it will be closed. ");
        }
        else
        {
            sb.Append("Your case has been assigned to our ").Append(complaint.AssignedOfficer)
              .Append(", and we are targeting resolution by ")
              .Append(complaint.SlaDueAt.ToString("dd-MMM-yyyy HH:mm")).Append(" UTC. ");
        }

        sb.Append("Kindly keep this reference number safe for any follow-up. Is there anything else I can help you with today?");
        return sb.ToString();
    }

    /// <summary>
    /// If Live Mode is on, ask Gemini to polish the already-correct deterministic reply into more
    /// natural Indian English. The deterministic text is always returned as-is if Live Mode is off
    /// or the call fails - it is never blank/broken because of a network problem.
    /// </summary>
    private async Task<string> PolishAsync(string deterministicReply, int? complaintId)
    {
        var settings = await _settingsService.GetAsync();

        if (settings.LiveModeEnabled && _llmRouter.IsConfigured(settings))
        {
            var systemPrompt = AgentCatalog.GetPrompt(TalkingAgentName);
            var userMessage =
                "Here is the message the platform's deterministic logic has already prepared for the customer - " +
                "polish it into warm, natural Indian English suitable for reading aloud, 2-4 short sentences, " +
                "keep the same meaning and do not drop the case reference number or any figures if present:\n\n" +
                deterministicReply;

            var result = await _llmRouter.InvokeAsync(systemPrompt, userMessage, settings);

            _context.AgentTokenUsages.Add(new AgentTokenUsage
            {
                ComplaintId = complaintId,
                AgentName = TalkingAgentName,
                Provider = settings.LlmProvider,
                Model = _llmRouter.ActiveModelName(settings),
                PromptTokens = result.PromptTokens,
                CompletionTokens = result.CompletionTokens,
                TotalTokens = result.TotalTokens,
                Success = result.Success,
                ErrorMessage = result.ErrorMessage,
                Timestamp = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();

            if (result.Success && !string.IsNullOrWhiteSpace(result.OutputText))
            {
                return result.OutputText;
            }
        }

        return deterministicReply;
    }
}
