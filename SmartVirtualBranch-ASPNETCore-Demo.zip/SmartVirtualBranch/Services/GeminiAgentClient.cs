using System.Text;
using System.Text.Json;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Thin wrapper around Google's Gemini "generateContent" REST endpoint.
/// https://ai.google.dev/api/generate-content - verify the model name and endpoint version
/// against current Gemini API docs, since both can change over time.
/// </summary>
public class GeminiAgentClient : IGeminiAgentClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<GeminiAgentClient> _logger;

    public GeminiAgentClient(IHttpClientFactory httpClientFactory, ILogger<GeminiAgentClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task<LlmAgentResult> InvokeAgentAsync(
        string systemPrompt,
        string userMessage,
        string model,
        string apiKey,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, "No Gemini API key is configured.");
        }

        if (string.IsNullOrWhiteSpace(model))
        {
            model = "gemini-2.0-flash";
        }

        try
        {
            var client = _httpClientFactory.CreateClient("gemini");
            var url = $"https://generativelanguage.googleapis.com/v1beta/models/{Uri.EscapeDataString(model)}:generateContent?key={apiKey}";

            var payload = new
            {
                system_instruction = new
                {
                    parts = new[] { new { text = systemPrompt } }
                },
                contents = new[]
                {
                    new { role = "user", parts = new[] { new { text = userMessage } } }
                },
                generationConfig = new
                {
                    temperature = 0.3,
                    maxOutputTokens = 400
                }
            };

            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            using var response = await client.PostAsync(url, content, cancellationToken);
            var raw = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var errorSnippet = raw.Length > 300 ? raw[..300] + "..." : raw;
                _logger.LogWarning("Gemini API call failed with {StatusCode}: {Body}", response.StatusCode, errorSnippet);
                return new LlmAgentResult(false, string.Empty, 0, 0, 0, $"HTTP {(int)response.StatusCode}: {errorSnippet}");
            }

            using var doc = JsonDocument.Parse(raw);
            var root = doc.RootElement;

            var text = root.TryGetProperty("candidates", out var candidates) && candidates.GetArrayLength() > 0
                ? candidates[0].GetProperty("content").GetProperty("parts")[0].GetProperty("text").GetString() ?? string.Empty
                : string.Empty;

            var promptTokens = 0;
            var completionTokens = 0;
            var totalTokens = 0;

            if (root.TryGetProperty("usageMetadata", out var usage))
            {
                if (usage.TryGetProperty("promptTokenCount", out var pt)) promptTokens = pt.GetInt32();
                if (usage.TryGetProperty("candidatesTokenCount", out var ct)) completionTokens = ct.GetInt32();
                totalTokens = usage.TryGetProperty("totalTokenCount", out var tt) ? tt.GetInt32() : promptTokens + completionTokens;
            }

            if (string.IsNullOrWhiteSpace(text))
            {
                return new LlmAgentResult(false, string.Empty, promptTokens, completionTokens, totalTokens,
                    "Gemini returned an empty response (it may have been blocked by a safety filter).");
            }

            return new LlmAgentResult(true, text.Trim(), promptTokens, completionTokens, totalTokens, null);
        }
        catch (TaskCanceledException)
        {
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, "The Gemini API call timed out.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error calling the Gemini API.");
            return new LlmAgentResult(false, string.Empty, 0, 0, 0, ex.Message);
        }
    }
}
