using Microsoft.EntityFrameworkCore;
using SmartVirtualBranch.Data;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// CRUD for the single Administrator-controlled AI settings row. Only AdminController
/// (which is [Authorize(Roles = "Administrator")]) is wired to call UpdateAsync.
/// </summary>
public class PlatformSettingsService : IPlatformSettingsService
{
    private readonly ApplicationDbContext _context;

    public PlatformSettingsService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<PlatformSettings> GetAsync()
    {
        var settings = await _context.PlatformSettings.FirstOrDefaultAsync();
        if (settings == null)
        {
            settings = new PlatformSettings();
            _context.PlatformSettings.Add(settings);
            await _context.SaveChangesAsync();
        }
        return settings;
    }

    public async Task UpdateAsync(PlatformSettingsUpdate update, string updatedBy)
    {
        var settings = await GetAsync();

        settings.LiveModeEnabled = update.LiveModeEnabled;
        settings.LlmProvider = update.LlmProvider is "Claude" or "Gemini" ? update.LlmProvider : "Gemini";

        // Only overwrite a stored key if the admin actually typed a new one - this lets the
        // masked key stay in place across saves without ever round-tripping the real key back
        // into the edit form.
        if (!string.IsNullOrWhiteSpace(update.NewGeminiApiKey))
        {
            settings.GeminiApiKey = update.NewGeminiApiKey.Trim();
        }
        if (!string.IsNullOrWhiteSpace(update.GeminiModel))
        {
            settings.GeminiModel = update.GeminiModel.Trim();
        }

        if (!string.IsNullOrWhiteSpace(update.NewClaudeApiKey))
        {
            settings.ClaudeApiKey = update.NewClaudeApiKey.Trim();
        }
        if (!string.IsNullOrWhiteSpace(update.ClaudeModel))
        {
            settings.ClaudeModel = update.ClaudeModel.Trim();
        }

        settings.CostPerMillionTokensUsd = update.CostPerMillionTokensUsd;

        settings.SpeechProvider = update.SpeechProvider is "ElevenLabs" or "Browser" ? update.SpeechProvider : "Browser";
        if (!string.IsNullOrWhiteSpace(update.NewElevenLabsApiKey))
        {
            settings.ElevenLabsApiKey = update.NewElevenLabsApiKey.Trim();
        }
        if (!string.IsNullOrWhiteSpace(update.ElevenLabsVoiceId))
        {
            settings.ElevenLabsVoiceId = update.ElevenLabsVoiceId.Trim();
        }

        settings.UpdatedAt = DateTime.UtcNow;
        settings.UpdatedBy = updatedBy;

        await _context.SaveChangesAsync();
    }
}
