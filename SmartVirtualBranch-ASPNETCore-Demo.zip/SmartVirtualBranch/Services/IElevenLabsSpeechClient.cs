namespace SmartVirtualBranch.Services;

public record SpeechSynthesisResult(bool Success, byte[]? AudioBytes, string? ErrorMessage);

/// <summary>
/// A real third-party text-to-speech engine for the AI Branch Officer's spoken replies - Anthropic
/// has no public speech API (see ClaudeAgentClient), so this is what actually produces natural
/// voice audio when an Administrator turns it on. Speech-to-text (listening to the customer) still
/// uses the browser's built-in Web Speech API in this demo - see Talk/Index.cshtml.
/// </summary>
public interface IElevenLabsSpeechClient
{
    Task<SpeechSynthesisResult> SynthesizeAsync(string text, string voiceId, string apiKey, CancellationToken cancellationToken = default);
}
