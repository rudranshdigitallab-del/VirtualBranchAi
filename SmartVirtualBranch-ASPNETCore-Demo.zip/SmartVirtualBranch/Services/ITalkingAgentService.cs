using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

public record TalkTurnResult(
    string NextState,
    string Reply,
    string? PendingMessage,
    string? ComplaintReference,
    string? RedirectUrl);

public interface ITalkingAgentService
{
    Task<TalkTurnResult> HandleTurnAsync(ApplicationUser user, string state, string message, string? pendingMessage, string channelSource);
}
