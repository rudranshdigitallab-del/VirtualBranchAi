using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

public interface IPlatformSettingsService
{
    Task<PlatformSettings> GetAsync();

    Task UpdateAsync(PlatformSettingsUpdate update, string updatedBy);
}

/// <summary>
/// All fields the Administrator can change on the AI Settings page in one call, so adding a new
/// setting doesn't mean growing an ever-longer positional parameter list.
/// </summary>
public record PlatformSettingsUpdate(
    bool LiveModeEnabled,
    string LlmProvider,
    string? NewGeminiApiKey,
    string GeminiModel,
    string? NewClaudeApiKey,
    string ClaudeModel,
    decimal CostPerMillionTokensUsd,
    string SpeechProvider,
    string? NewElevenLabsApiKey,
    string ElevenLabsVoiceId);
