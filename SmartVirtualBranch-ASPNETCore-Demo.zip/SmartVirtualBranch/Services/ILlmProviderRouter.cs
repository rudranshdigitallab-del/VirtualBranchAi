using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

/// <summary>
/// Picks Gemini or Claude based on the Administrator's PlatformSettings.LlmProvider choice, so every
/// call site (the orchestration pipeline, the Talking Agent's polish step, the Expert Chat AI
/// summary) goes through one place instead of branching on the provider itself.
/// </summary>
public interface ILlmProviderRouter
{
    bool IsConfigured(PlatformSettings settings);

    string ActiveModelName(PlatformSettings settings);

    Task<LlmAgentResult> InvokeAsync(string systemPrompt, string userMessage, PlatformSettings settings, CancellationToken cancellationToken = default);
}
