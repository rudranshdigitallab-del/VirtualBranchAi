using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

public interface IComplaintAgentPipelineService
{
    /// <param name="notifier">
    /// Optional - when provided, each timeline step is pushed live over SignalR the moment it's
    /// produced (instead of only appearing once the whole pipeline finishes and the page reloads).
    /// </param>
    Task<List<ComplaintTimelineEvent>> RunPipelineAsync(Complaint complaint, ICaseRealtimeNotifier? notifier = null);

    /// <summary>
    /// Posts the AI Case Agent's opening message in the case's Expert Chat - a summary of what the
    /// pipeline decided and why, addressed to whichever officer/queue it was routed to. Called once,
    /// right after <see cref="RunPipelineAsync"/> and its events have been saved.
    /// </summary>
    Task PostInitialExpertChatSummaryAsync(Complaint complaint, ICaseRealtimeNotifier? notifier = null);
}
