using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

public class LlmProviderRouter : ILlmProviderRouter
{
    private readonly IGeminiAgentClient _gemini;
    private readonly IClaudeAgentClient _claude;

    public LlmProviderRouter(IGeminiAgentClient gemini, IClaudeAgentClient claude)
    {
        _gemini = gemini;
        _claude = claude;
    }

    public bool IsConfigured(PlatformSettings settings) =>
        settings.LlmProvider == "Claude"
            ? !string.IsNullOrWhiteSpace(settings.ClaudeApiKey)
            : !string.IsNullOrWhiteSpace(settings.GeminiApiKey);

    public string ActiveModelName(PlatformSettings settings) =>
        settings.LlmProvider == "Claude" ? settings.ClaudeModel : settings.GeminiModel;

    public Task<LlmAgentResult> InvokeAsync(string systemPrompt, string userMessage, PlatformSettings settings, CancellationToken cancellationToken = default) =>
        settings.LlmProvider == "Claude"
            ? _claude.InvokeAgentAsync(systemPrompt, userMessage, settings.ClaudeModel, settings.ClaudeApiKey, cancellationToken)
            : _gemini.InvokeAgentAsync(systemPrompt, userMessage, settings.GeminiModel, settings.GeminiApiKey, cancellationToken);
}
