using Microsoft.AspNetCore.SignalR;
using SmartVirtualBranch.Hubs;
using SmartVirtualBranch.Models;

namespace SmartVirtualBranch.Services;

public class CaseRealtimeNotifier : ICaseRealtimeNotifier
{
    private readonly IHubContext<CaseHub> _hub;

    public CaseRealtimeNotifier(IHubContext<CaseHub> hub)
    {
        _hub = hub;
    }

    public Task TimelineEventAddedAsync(int complaintId, ComplaintTimelineEvent ev) =>
        _hub.Clients.Group(CaseHub.GroupName(complaintId)).SendAsync("TimelineEvent", new
        {
            phase = ev.Phase,
            agentName = ev.AgentName,
            action = ev.Action,
            output = ev.Output,
            timestamp = ev.Timestamp
        });

    public Task ExpertChatMessageAddedAsync(int complaintId, ExpertChatMessage message) =>
        _hub.Clients.Group(CaseHub.GroupName(complaintId)).SendAsync("ExpertChatMessage", new
        {
            senderType = message.SenderType,
            senderName = message.SenderName,
            message = message.Message,
            timestamp = message.Timestamp
        });

    public Task StatusChangedAsync(int complaintId, string status, string priority, string assignedOfficer) =>
        _hub.Clients.Group(CaseHub.GroupName(complaintId)).SendAsync("StatusChanged", new
        {
            status,
            priority,
            assignedOfficer
        });

    public Task ProcessingStartedAsync(int complaintId) =>
        _hub.Clients.Group(CaseHub.GroupName(complaintId)).SendAsync("ProcessingStarted");

    public Task ProcessingCompletedAsync(int complaintId, string redirectUrl) =>
        _hub.Clients.Group(CaseHub.GroupName(complaintId)).SendAsync("ProcessingCompleted", redirectUrl);
}
